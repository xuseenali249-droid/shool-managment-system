import { useQuery } from "@tanstack/react-query";
import { Calendar, Users, UserCheck, UserX, CalendarDays, BarChart3, FileText, ChevronRight } from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

interface DashboardStats {
  totalStudents: number;
  presentToday: number;
}

export default function Attendance() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const totalStudents = stats?.totalStudents || 0;
  const presentToday = stats?.presentToday || 0;
  const absentToday = totalStudents - presentToday;
  const attendanceRate = totalStudents > 0 ? ((presentToday / totalStudents) * 100).toFixed(1) : "0";

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Attendance Management</h2>
        <p className="text-gray-600">Track and manage student and teacher attendance</p>
      </div>

      {/* Attendance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Today's Attendance</h3>
              <CalendarDays className="h-8 w-8 text-primary" />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{attendanceRate}%</div>
            <p className="text-sm text-success">+2.3% from yesterday</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Present Students</h3>
              <UserCheck className="h-8 w-8 text-success" />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{presentToday.toLocaleString()}</div>
            <p className="text-sm text-gray-500">out of {totalStudents.toLocaleString()} total</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Absent Students</h3>
              <UserX className="h-8 w-8 text-accent" />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{absentToday}</div>
            <p className="text-sm text-gray-500">requires follow-up</p>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Take Attendance */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Take Attendance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                Select Class
              </Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10-a">Grade 10-A</SelectItem>
                  <SelectItem value="10-b">Grade 10-B</SelectItem>
                  <SelectItem value="11-a">Grade 11-A</SelectItem>
                  <SelectItem value="11-b">Grade 11-B</SelectItem>
                  <SelectItem value="12-a">Grade 12-A</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </Label>
              <Input 
                type="date" 
                defaultValue={new Date().toISOString().split('T')[0]}
              />
            </div>
            
            <Button className="w-full bg-primary hover:bg-primary/90">
              <Users className="mr-2 h-4 w-4" />
              Start Attendance
            </Button>
          </CardContent>
        </Card>

        {/* Attendance Reports */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Attendance Reports
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <BarChart3 className="text-primary mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Daily Report</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <BarChart3 className="text-secondary mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Weekly Report</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <BarChart3 className="text-warning mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Monthly Report</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <FileText className="text-gray-600 mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Custom Report</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
