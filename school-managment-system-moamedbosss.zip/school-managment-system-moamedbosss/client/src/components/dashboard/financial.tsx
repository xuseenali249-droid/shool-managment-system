import { useQuery } from "@tanstack/react-query";
import { 
  DollarSign, Clock, AlertTriangle, CheckCircle, FileText, 
  CreditCard, Bell, Settings, Plus, ChevronRight 
} from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface DashboardStats {
  monthlyRevenue: number;
  pendingAmount: number;
  overdueAmount: number;
}

interface FeeWithStudent {
  id: number;
  studentId: number;
  amount: string;
  feeType: string;
  dueDate: Date;
  status: string;
  description?: string;
  createdAt: Date;
  student?: {
    id: number;
    studentId: string;
    grade: string;
    section: string;
    user?: {
      firstName: string;
      lastName: string;
    };
  };
}

interface Payment {
  id: number;
  feeId: number;
  amount: string;
  paymentMethod: string;
  transactionId?: string;
  paidAt: Date;
  receivedBy: number;
}

export default function Financial() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: fees, isLoading: feesLoading } = useQuery<FeeWithStudent[]>({
    queryKey: ["/api/fees"],
  });

  const { data: payments, isLoading: paymentsLoading } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
  });

  const isLoading = statsLoading || feesLoading || paymentsLoading;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const formatCurrency = (amount: string | number) => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(numAmount);
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString();
  };

  const formatTime = (date: Date | string) => {
    const now = new Date();
    const paymentDate = new Date(date);
    const diffHours = Math.floor((now.getTime() - paymentDate.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  // Calculate derived stats
  const totalPaidThisMonth = payments?.reduce((sum, payment) => 
    sum + parseFloat(payment.amount), 0) || 0;
  
  const totalPayments = payments?.length || 0;

  // Get recent payments (last 5)
  const recentPayments = payments
    ?.sort((a, b) => new Date(b.paidAt).getTime() - new Date(a.paidAt).getTime())
    ?.slice(0, 5) || [];

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Financial Management</h2>
        <p className="text-gray-600">Manage fees, payments, billing, and financial reports</p>
      </div>

      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard
          title="Monthly Revenue"
          value={formatCurrency(stats?.monthlyRevenue || 0)}
          change="+18%"
          changeType="positive"
          icon={DollarSign}
          iconColor="text-success"
        />
        <StatsCard
          title="Pending Payments"
          value={formatCurrency(stats?.pendingAmount || 0)}
          change={`${fees?.filter(f => f.status === 'pending').length || 0} students`}
          changeType="neutral"
          icon={Clock}
          iconColor="text-warning"
        />
        <StatsCard
          title="Overdue Amount"
          value={formatCurrency(stats?.overdueAmount || 0)}
          change={`${fees?.filter(f => f.status === 'overdue').length || 0} students`}
          changeType="negative"
          icon={AlertTriangle}
          iconColor="text-accent"
        />
        <StatsCard
          title="Paid This Month"
          value={formatCurrency(totalPaidThisMonth)}
          change={`${totalPayments} payments`}
          changeType="positive"
          icon={CheckCircle}
          iconColor="text-primary"
        />
      </div>

      {/* Financial Management Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fee Management */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Fee Management
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <FileText className="text-primary mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Generate Invoices</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <CreditCard className="text-secondary mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Record Payment</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <Bell className="text-warning mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Send Reminders</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100"
            >
              <div className="flex items-center">
                <Settings className="text-gray-600 mr-3 h-5 w-5" />
                <span className="text-sm font-medium text-gray-900">Fee Structure</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
          </CardContent>
        </Card>

        {/* Recent Payments */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Recent Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentPayments.length > 0 ? (
              <div className="space-y-4">
                {recentPayments.map((payment) => {
                  // Find the corresponding fee to get student info
                  const fee = fees?.find(f => f.id === payment.feeId);
                  const studentName = fee?.student?.user 
                    ? `${fee.student.user.firstName} ${fee.student.user.lastName}`
                    : "Unknown Student";
                  const grade = fee?.student 
                    ? `Grade ${fee.student.grade}-${fee.student.section}`
                    : "Unknown Grade";

                  return (
                    <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <CheckCircle className="text-success h-5 w-5" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{studentName}</p>
                          <p className="text-xs text-gray-500">{grade}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">
                          {formatCurrency(payment.amount)}
                        </p>
                        <p className="text-xs text-gray-500">{formatTime(payment.paidAt)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No recent payments</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
