import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Database, RefreshCw, CheckCircle, XCircle, AlertCircle, Users, GraduationCap } from "lucide-react";

interface NotionStatus {
  status: 'connected' | 'not_configured' | 'error';
  hasSecret: boolean;
  hasPageUrl: boolean;
  error?: string;
}

export default function NotionIntegration() {
  const [status, setStatus] = useState<NotionStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [setupLoading, setSetupLoading] = useState(false);
  const [syncLoading, setSyncLoading] = useState({ students: false, teachers: false });
  const [notionData, setNotionData] = useState({ students: [], teachers: [] });
  const { toast } = useToast();

  const checkNotionStatus = async () => {
    setLoading(true);
    try {
      const response = await apiRequest('/api/notion/status');
      setStatus(response);
    } catch (error) {
      console.error('Error checking Notion status:', error);
      setStatus({ status: 'error', hasSecret: false, hasPageUrl: false, error: 'Failed to check status' });
    } finally {
      setLoading(false);
    }
  };

  const setupNotionDatabases = async () => {
    setSetupLoading(true);
    try {
      const response = await apiRequest('/api/notion/setup', {
        method: 'POST',
      });
      
      toast({
        title: "Success",
        description: "Notion databases created successfully",
      });
      
      await checkNotionStatus();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to setup Notion databases",
        variant: "destructive",
      });
    } finally {
      setSetupLoading(false);
    }
  };

  const syncStudents = async () => {
    setSyncLoading(prev => ({ ...prev, students: true }));
    try {
      const students = await apiRequest('/api/notion/sync/students');
      setNotionData(prev => ({ ...prev, students }));
      toast({
        title: "Success",
        description: `Synced ${students.length} students from Notion`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sync students from Notion",
        variant: "destructive",
      });
    } finally {
      setSyncLoading(prev => ({ ...prev, students: false }));
    }
  };

  const syncTeachers = async () => {
    setSyncLoading(prev => ({ ...prev, teachers: true }));
    try {
      const teachers = await apiRequest('/api/notion/sync/teachers');
      setNotionData(prev => ({ ...prev, teachers }));
      toast({
        title: "Success",
        description: `Synced ${teachers.length} teachers from Notion`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sync teachers from Notion",
        variant: "destructive",
      });
    } finally {
      setSyncLoading(prev => ({ ...prev, teachers: false }));
    }
  };

  useEffect(() => {
    checkNotionStatus();
  }, []);

  const getStatusBadge = () => {
    if (!status) return null;
    
    switch (status.status) {
      case 'connected':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case 'not_configured':
        return <Badge variant="secondary"><AlertCircle className="w-3 h-3 mr-1" />Not Configured</Badge>;
      case 'error':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Notion Integration</h2>
          <p className="text-muted-foreground">Sync school data with your Notion workspace</p>
        </div>
        <Button 
          onClick={checkNotionStatus} 
          disabled={loading}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh Status
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Connection Status
            {getStatusBadge()}
          </CardTitle>
          <CardDescription>
            Current status of the Notion integration
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {status && (
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <span>Integration Secret</span>
                {status.hasSecret ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <span>Page URL</span>
                {status.hasPageUrl ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
              </div>
            </div>
          )}

          {status?.error && (
            <div className="p-3 border border-red-200 bg-red-50 rounded-lg">
              <p className="text-sm text-red-700">{status.error}</p>
            </div>
          )}

          {status?.status === 'not_configured' && (
            <div className="p-4 border border-orange-200 bg-orange-50 rounded-lg">
              <h4 className="font-medium text-orange-800 mb-2">Setup Required</h4>
              <p className="text-sm text-orange-700 mb-3">
                Please configure your Notion integration credentials in the environment variables:
              </p>
              <ul className="text-sm text-orange-700 space-y-1 mb-3">
                <li>• NOTION_INTEGRATION_SECRET</li>
                <li>• NOTION_PAGE_URL</li>
              </ul>
              <p className="text-xs text-orange-600">
                Contact your administrator to set up these credentials.
              </p>
            </div>
          )}

          {status?.status === 'connected' && (
            <div className="space-y-4">
              <Separator />
              <div>
                <h4 className="font-medium mb-3">Database Management</h4>
                <Button 
                  onClick={setupNotionDatabases} 
                  disabled={setupLoading}
                  className="w-full"
                >
                  {setupLoading ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Database className="w-4 h-4 mr-2" />
                  )}
                  Setup Notion Databases
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  Creates Students and Teachers databases in your Notion workspace
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {status?.status === 'connected' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Students Sync
              </CardTitle>
              <CardDescription>
                Sync student data from Notion
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={syncStudents} 
                disabled={syncLoading.students}
                className="w-full"
              >
                {syncLoading.students ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Users className="w-4 h-4 mr-2" />
                )}
                Sync Students
              </Button>
              {notionData.students.length > 0 && (
                <div className="p-3 border rounded-lg">
                  <p className="text-sm font-medium">Last Sync Result</p>
                  <p className="text-sm text-muted-foreground">
                    {notionData.students.length} students synced from Notion
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Teachers Sync
              </CardTitle>
              <CardDescription>
                Sync teacher data from Notion
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={syncTeachers} 
                disabled={syncLoading.teachers}
                className="w-full"
              >
                {syncLoading.teachers ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Users className="w-4 h-4 mr-2" />
                )}
                Sync Teachers
              </Button>
              {notionData.teachers.length > 0 && (
                <div className="p-3 border rounded-lg">
                  <p className="text-sm font-medium">Last Sync Result</p>
                  <p className="text-sm text-muted-foreground">
                    {notionData.teachers.length} teachers synced from Notion
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}