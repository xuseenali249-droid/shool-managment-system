import { useQuery } from "@tanstack/react-query";
import { 
  Users, BookOpen, DoorOpen, DollarSign, UserPlus, 
  CheckCircle, AlertTriangle, FileText 
} from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface DashboardStats {
  totalStudents: number;
  totalTeachers: number;
  activeClasses: number;
  monthlyRevenue: number;
  pendingAmount: number;
  overdueAmount: number;
  presentToday: number;
}

export default function Overview() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!stats) {
    return <div>Failed to load dashboard statistics</div>;
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Students"
          value={stats.totalStudents.toLocaleString()}
          change="+12%"
          changeType="positive"
          icon={Users}
          iconColor="text-primary"
        />
        <StatsCard
          title="Total Teachers"
          value={stats.totalTeachers}
          change="+3%"
          changeType="positive"
          icon={BookOpen}
          iconColor="text-secondary"
        />
        <StatsCard
          title="Active Classes"
          value={stats.activeClasses}
          change="+1 new this week"
          changeType="neutral"
          icon={DoorOpen}
          iconColor="text-warning"
        />
        <StatsCard
          title="Monthly Revenue"
          value={formatCurrency(stats.monthlyRevenue)}
          change="+18%"
          changeType="positive"
          icon={DollarSign}
          iconColor="text-accent"
        />
      </div>

      {/* Recent Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <UserPlus className="text-primary text-sm h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">New student enrolled</p>
                  <p className="text-xs text-gray-500">Sarah Johnson joined Grade 10-A</p>
                  <p className="text-xs text-gray-400 mt-1">2 hours ago</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="text-success text-sm h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Fee payment received</p>
                  <p className="text-xs text-gray-500">$1,200 from Michael Brown</p>
                  <p className="text-xs text-gray-400 mt-1">4 hours ago</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="text-warning text-sm h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Attendance alert</p>
                  <p className="text-xs text-gray-500">Low attendance in Chemistry class</p>
                  <p className="text-xs text-gray-400 mt-1">6 hours ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline"
                className="p-4 h-auto flex flex-col items-center space-y-2 bg-blue-50 hover:bg-blue-100 border-blue-200"
              >
                <UserPlus className="text-primary text-2xl h-8 w-8" />
                <span className="text-sm font-medium text-gray-900">Add Student</span>
              </Button>
              
              <Button 
                variant="outline"
                className="p-4 h-auto flex flex-col items-center space-y-2 bg-green-50 hover:bg-green-100 border-green-200"
              >
                <BookOpen className="text-secondary text-2xl h-8 w-8" />
                <span className="text-sm font-medium text-gray-900">Add Teacher</span>
              </Button>
              
              <Button 
                variant="outline"
                className="p-4 h-auto flex flex-col items-center space-y-2 bg-yellow-50 hover:bg-yellow-100 border-yellow-200"
              >
                <Users className="text-warning text-2xl h-8 w-8" />
                <span className="text-sm font-medium text-gray-900">Take Attendance</span>
              </Button>
              
              <Button 
                variant="outline"
                className="p-4 h-auto flex flex-col items-center space-y-2 bg-red-50 hover:bg-red-100 border-red-200"
              >
                <FileText className="text-accent text-2xl h-8 w-8" />
                <span className="text-sm font-medium text-gray-900">Generate Invoice</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
