import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  FileText, Download, Calendar, Users, GraduationCap, 
  DollarSign, TrendingUp, Filter, Search, Eye
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface ReportData {
  students: any[];
  teachers: any[];
  attendance: any[];
  fees: any[];
  payments: any[];
  stats: any;
}

export default function Reports() {
  const [reportType, setReportType] = useState("overview");
  const [dateRange, setDateRange] = useState("month");
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch all data for reports
  const { data: students = [] } = useQuery({ queryKey: ["/api/students"] });
  const { data: teachers = [] } = useQuery({ queryKey: ["/api/teachers"] });
  const { data: attendance = [] } = useQuery({ queryKey: ["/api/attendance"] });
  const { data: fees = [] } = useQuery({ queryKey: ["/api/fees"] });
  const { data: payments = [] } = useQuery({ queryKey: ["/api/payments"] });
  const { data: stats } = useQuery({ queryKey: ["/api/dashboard/stats"] });

  const reportTypes = [
    { id: "overview", label: "School Overview", icon: TrendingUp },
    { id: "students", label: "Student Report", icon: GraduationCap },
    { id: "teachers", label: "Teacher Report", icon: Users },
    { id: "attendance", label: "Attendance Report", icon: Calendar },
    { id: "financial", label: "Financial Report", icon: DollarSign },
  ];

  const handleExportReport = (format: 'pdf' | 'excel') => {
    console.log(`Exporting ${reportType} report as ${format}`);
    // Export functionality would be implemented here
  };

  const renderOverviewReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm font-medium">Total Students</p>
                <p className="text-2xl font-bold text-blue-700">{stats?.totalStudents || 0}</p>
              </div>
              <GraduationCap className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">Total Teachers</p>
                <p className="text-2xl font-bold text-green-700">{stats?.totalTeachers || 0}</p>
              </div>
              <Users className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 text-sm font-medium">Monthly Revenue</p>
                <p className="text-2xl font-bold text-purple-700">${stats?.monthlyRevenue || 0}</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-600 text-sm font-medium">Attendance Rate</p>
                <p className="text-2xl font-bold text-orange-700">
                  {stats?.totalStudents ? Math.round((stats.presentToday / stats.totalStudents) * 100) : 0}%
                </p>
              </div>
              <Calendar className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>School Performance Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Student Distribution by Grade</h4>
                <div className="space-y-2">
                  {Object.entries(
                    students.reduce((acc: any, student: any) => {
                      acc[student.grade] = (acc[student.grade] || 0) + 1;
                      return acc;
                    }, {})
                  ).map(([grade, count]) => (
                    <div key={grade} className="flex justify-between">
                      <span>{grade}</span>
                      <Badge variant="secondary">{count as number}</Badge>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2">Fee Collection Status</h4>
                <div className="space-y-2">
                  {Object.entries(
                    fees.reduce((acc: any, fee: any) => {
                      acc[fee.status] = (acc[fee.status] || 0) + 1;
                      return acc;
                    }, {})
                  ).map(([status, count]) => (
                    <div key={status} className="flex justify-between">
                      <span className="capitalize">{status}</span>
                      <Badge variant={status === 'paid' ? 'default' : 'destructive'}>
                        {count as number}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderStudentReport = () => (
    <Card>
      <CardHeader>
        <CardTitle>Student Report</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Student ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Grade</TableHead>
              <TableHead>Section</TableHead>
              <TableHead>Enrollment Date</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students
              .filter((student: any) => 
                student.studentId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                student.grade?.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map((student: any) => (
                <TableRow key={student.id}>
                  <TableCell>{student.studentId}</TableCell>
                  <TableCell>{student.user?.firstName} {student.user?.lastName}</TableCell>
                  <TableCell>{student.grade}</TableCell>
                  <TableCell>{student.section}</TableCell>
                  <TableCell>{new Date(student.enrollmentDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Badge variant={student.user?.isActive ? "default" : "secondary"}>
                      {student.user?.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );

  const renderTeacherReport = () => (
    <Card>
      <CardHeader>
        <CardTitle>Teacher Report</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Employee ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Subject</TableHead>
              <TableHead>Experience</TableHead>
              <TableHead>Hire Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {teachers
              .filter((teacher: any) => 
                teacher.employeeId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                teacher.subject?.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map((teacher: any) => (
                <TableRow key={teacher.id}>
                  <TableCell>{teacher.employeeId}</TableCell>
                  <TableCell>{teacher.user?.firstName} {teacher.user?.lastName}</TableCell>
                  <TableCell>{teacher.department}</TableCell>
                  <TableCell>{teacher.subject}</TableCell>
                  <TableCell>{teacher.experience} years</TableCell>
                  <TableCell>{new Date(teacher.hireDate).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );

  const renderAttendanceReport = () => (
    <Card>
      <CardHeader>
        <CardTitle>Attendance Report</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <p className="text-sm text-gray-600">
            Overall attendance rate: {stats?.totalStudents ? Math.round((stats.presentToday / stats.totalStudents) * 100) : 0}%
          </p>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Total Students</TableHead>
              <TableHead>Present</TableHead>
              <TableHead>Absent</TableHead>
              <TableHead>Attendance Rate</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>{new Date().toLocaleDateString()}</TableCell>
              <TableCell>{stats?.totalStudents || 0}</TableCell>
              <TableCell>{stats?.presentToday || 0}</TableCell>
              <TableCell>{(stats?.totalStudents || 0) - (stats?.presentToday || 0)}</TableCell>
              <TableCell>
                <Badge variant="default">
                  {stats?.totalStudents ? Math.round((stats.presentToday / stats.totalStudents) * 100) : 0}%
                </Badge>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );

  const renderFinancialReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-gray-500">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600">${stats?.monthlyRevenue || 0}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-gray-500">Pending Amount</p>
              <p className="text-2xl font-bold text-yellow-600">${stats?.pendingAmount || 0}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-gray-500">Overdue Amount</p>
              <p className="text-2xl font-bold text-red-600">${stats?.overdueAmount || 0}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Fee Collection Details</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Fee Type</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {fees.slice(0, 10).map((fee: any) => (
                <TableRow key={fee.id}>
                  <TableCell>{fee.student?.studentId}</TableCell>
                  <TableCell>{fee.feeType}</TableCell>
                  <TableCell>${fee.amount}</TableCell>
                  <TableCell>{new Date(fee.dueDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Badge variant={fee.status === 'paid' ? 'default' : 'destructive'}>
                      {fee.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );

  const renderReport = () => {
    switch (reportType) {
      case "students":
        return renderStudentReport();
      case "teachers":
        return renderTeacherReport();
      case "attendance":
        return renderAttendanceReport();
      case "financial":
        return renderFinancialReport();
      default:
        return renderOverviewReport();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Reports & Analytics</h2>
          <p className="text-gray-600">Generate and view comprehensive school reports</p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => handleExportReport('pdf')}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export PDF
          </Button>
          <Button 
            variant="outline"
            onClick={() => handleExportReport('excel')}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export Excel
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Date Range</label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="quarter">This Quarter</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex items-end">
              <Button className="w-full">
                <Filter className="h-4 w-4 mr-2" />
                Apply Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      {renderReport()}
    </div>
  );
}