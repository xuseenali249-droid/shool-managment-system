import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Brain, Search, TrendingUp, BarChart3, Users, 
  GraduationCap, Lightbulb, Target, ChevronRight,
  Zap, BookOpen, MessageSquare, Download, RefreshCw
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AIInsight {
  id: string;
  type: 'performance' | 'attendance' | 'financial' | 'prediction';
  title: string;
  description: string;
  confidence: number;
  recommendations: string[];
  data?: any;
}

interface ResearchQuery {
  id: string;
  query: string;
  type: 'educational' | 'policy' | 'best_practices' | 'trends';
  results: any[];
  timestamp: Date;
}

export default function ResearchAI() {
  const [activeTab, setActiveTab] = useState("insights");
  const [searchQuery, setSearchQuery] = useState("");
  const [researchType, setResearchType] = useState("educational");
  const [analysisQuery, setAnalysisQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch AI insights
  const { data: insights = [], isLoading: insightsLoading } = useQuery({
    queryKey: ["/api/ai/insights"],
    queryFn: () => apiRequest("/api/ai/insights"),
  });

  // Fetch research history
  const { data: researchHistory = [] } = useQuery({
    queryKey: ["/api/ai/research"],
    queryFn: () => apiRequest("/api/ai/research"),
  });

  // Generate AI insights mutation
  const generateInsightsMutation = useMutation({
    mutationFn: () => apiRequest("/api/ai/generate-insights", { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/insights"] });
      toast({
        title: "AI Analysis Complete",
        description: "New insights have been generated from your school data",
      });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Failed to generate AI insights. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Research query mutation
  const researchMutation = useMutation({
    mutationFn: (data: { query: string; type: string }) => 
      apiRequest("/api/ai/research", { 
        method: "POST", 
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/research"] });
      setSearchQuery("");
      toast({
        title: "Research Complete",
        description: "Educational research results have been compiled",
      });
    },
    onError: () => {
      toast({
        title: "Research Failed",
        description: "Failed to complete research query. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Custom analysis mutation
  const analysisMutation = useMutation({
    mutationFn: (query: string) => 
      apiRequest("/api/ai/analyze", { 
        method: "POST", 
        body: JSON.stringify({ query }),
        headers: { "Content-Type": "application/json" }
      }),
    onSuccess: (data) => {
      toast({
        title: "Analysis Complete",
        description: "AI analysis has been completed",
      });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Failed to complete AI analysis. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleResearch = () => {
    if (!searchQuery.trim()) return;
    researchMutation.mutate({ query: searchQuery, type: researchType });
  };

  const handleAnalysis = () => {
    if (!analysisQuery.trim()) return;
    analysisMutation.mutate(analysisQuery);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'performance': return TrendingUp;
      case 'attendance': return Users;
      case 'financial': return BarChart3;
      case 'prediction': return Target;
      default: return Lightbulb;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "bg-green-100 text-green-800";
    if (confidence >= 60) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const tabs = [
    { id: "insights", label: "AI Insights", icon: Brain },
    { id: "research", label: "Educational Research", icon: Search },
    { id: "analysis", label: "Custom Analysis", icon: MessageSquare },
  ];

  const renderInsights = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">AI-Generated Insights</h3>
          <p className="text-sm text-gray-600">Intelligent analysis of your school data</p>
        </div>
        <Button 
          onClick={() => generateInsightsMutation.mutate()}
          disabled={generateInsightsMutation.isPending}
          className="flex items-center gap-2"
        >
          {generateInsightsMutation.isPending ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Zap className="h-4 w-4" />
          )}
          Generate New Insights
        </Button>
      </div>

      {insightsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-24 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {insights.map((insight: AIInsight) => {
            const Icon = getInsightIcon(insight.type);
            return (
              <Card key={insight.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon className="h-5 w-5 text-primary" />
                      <CardTitle className="text-lg">{insight.title}</CardTitle>
                    </div>
                    <Badge className={getConfidenceColor(insight.confidence)}>
                      {insight.confidence}% confidence
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{insight.description}</p>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Recommendations:</h4>
                    <ul className="space-y-1">
                      {insight.recommendations.map((rec, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                          <ChevronRight className="h-3 w-3 mt-0.5 text-primary flex-shrink-0" />
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {insights.length === 0 && !insightsLoading && (
        <Card className="text-center py-12">
          <CardContent>
            <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="font-medium text-gray-900 mb-2">No Insights Available</h3>
            <p className="text-gray-500 mb-4">Generate AI insights from your school data</p>
            <Button onClick={() => generateInsightsMutation.mutate()}>
              Generate First Insights
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderResearch = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-2">Educational Research</h3>
        <p className="text-sm text-gray-600">Search for educational trends, policies, and best practices</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <Input
                  placeholder="Enter your research query..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleResearch()}
                />
              </div>
              <Select value={researchType} onValueChange={setResearchType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="educational">Educational Trends</SelectItem>
                  <SelectItem value="policy">Education Policy</SelectItem>
                  <SelectItem value="best_practices">Best Practices</SelectItem>
                  <SelectItem value="trends">Technology Trends</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={handleResearch}
              disabled={researchMutation.isPending || !searchQuery.trim()}
              className="w-full"
            >
              {researchMutation.isPending ? (
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Search className="h-4 w-4 mr-2" />
              )}
              Search Educational Resources
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h4 className="font-medium">Recent Research</h4>
        {researchHistory.length > 0 ? (
          researchHistory.map((research: ResearchQuery) => (
            <Card key={research.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium">{research.query}</h5>
                  <Badge variant="outline">{research.type}</Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  {new Date(research.timestamp).toLocaleDateString()}
                </p>
                <div className="text-sm">
                  <span className="text-gray-500">Results: </span>
                  <span className="font-medium">{research.results?.length || 0} sources found</span>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="text-center py-8">
            <CardContent>
              <BookOpen className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">No research history yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );

  const renderAnalysis = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-2">Custom AI Analysis</h3>
        <p className="text-sm text-gray-600">Ask specific questions about your school data</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <Textarea
              placeholder="Ask a question about your school data (e.g., 'What factors are affecting student attendance?' or 'How can we improve fee collection rates?')"
              value={analysisQuery}
              onChange={(e) => setAnalysisQuery(e.target.value)}
              rows={4}
            />
            <Button 
              onClick={handleAnalysis}
              disabled={analysisMutation.isPending || !analysisQuery.trim()}
              className="w-full"
            >
              {analysisMutation.isPending ? (
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Brain className="h-4 w-4 mr-2" />
              )}
              Analyze with AI
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Sample Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              "What are the main factors affecting student performance?",
              "How can we improve attendance rates?",
              "Which students are at risk of dropping out?",
              "What's the optimal fee collection strategy?",
              "How does teacher workload affect student outcomes?",
              "What trends do you see in our enrollment data?"
            ].map((question, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => setAnalysisQuery(question)}
                className="text-left justify-start h-auto p-3 whitespace-normal"
              >
                {question}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Research & AI Analytics
          </h2>
          <p className="text-gray-600">Intelligent insights and educational research tools</p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === "insights" && renderInsights()}
      {activeTab === "research" && renderResearch()}
      {activeTab === "analysis" && renderAnalysis()}
    </div>
  );
}