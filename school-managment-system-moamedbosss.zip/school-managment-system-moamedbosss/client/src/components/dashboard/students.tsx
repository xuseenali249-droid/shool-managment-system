import { useQuery } from "@tanstack/react-query";
import { Users, CalendarCheck, UserPlus, GraduationCap, Plus, Eye, Edit, UserMinus } from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface StudentWithUser {
  id: number;
  userId: number;
  studentId: string;
  grade: string;
  section: string;
  dateOfBirth: Date;
  guardianName: string;
  guardianPhone: string;
  guardianEmail?: string;
  address?: string;
  enrollmentDate: Date;
  user?: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    isActive: boolean;
  };
}

export default function Students() {
  const { data: students, isLoading } = useQuery<StudentWithUser[]>({
    queryKey: ["/api/students"],
  });

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString();
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const totalStudents = students?.length || 0;
  const presentToday = Math.floor(totalStudents * 0.925); // 92.5% attendance
  const newAdmissions = Math.floor(totalStudents * 0.02); // 2% assumed new
  const graduates = Math.floor(totalStudents * 0.11); // 11% assumed graduates

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Students Management</h2>
        <p className="text-gray-600">Manage student records, enrollment, and academic information</p>
      </div>

      {/* Student Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard
          title="Total Students"
          value={totalStudents.toLocaleString()}
          icon={Users}
          iconColor="text-primary"
        />
        <StatsCard
          title="Present Today"
          value={presentToday.toLocaleString()}
          icon={CalendarCheck}
          iconColor="text-success"
        />
        <StatsCard
          title="New Admissions"
          value={newAdmissions}
          icon={UserPlus}
          iconColor="text-secondary"
        />
        <StatsCard
          title="Graduates"
          value={graduates}
          icon={GraduationCap}
          iconColor="text-warning"
        />
      </div>

      {/* Students Directory */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">
              Students Directory
            </CardTitle>
            <div className="flex space-x-3">
              <Select>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="All Grades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Grades</SelectItem>
                  <SelectItem value="9">Grade 9</SelectItem>
                  <SelectItem value="10">Grade 10</SelectItem>
                  <SelectItem value="11">Grade 11</SelectItem>
                  <SelectItem value="12">Grade 12</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-primary hover:bg-primary/90" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Student
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="font-medium text-gray-500">Student</TableHead>
                  <TableHead className="font-medium text-gray-500">Grade</TableHead>
                  <TableHead className="font-medium text-gray-500">Guardian</TableHead>
                  <TableHead className="font-medium text-gray-500">Enrolled</TableHead>
                  <TableHead className="font-medium text-gray-500">Status</TableHead>
                  <TableHead className="font-medium text-gray-500">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students?.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-primary font-medium text-sm">
                            {student.user?.firstName[0]}{student.user?.lastName[0]}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {student.user?.firstName} {student.user?.lastName}
                          </div>
                          <div className="text-sm text-gray-500">
                            ID: {student.studentId}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      {student.grade}-{student.section}
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      <div>
                        <div>{student.guardianName}</div>
                        <div className="text-xs text-gray-500">{student.guardianPhone}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      {formatDate(student.enrollmentDate)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={student.user?.isActive ? "default" : "secondary"}>
                        {student.user?.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-800">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
