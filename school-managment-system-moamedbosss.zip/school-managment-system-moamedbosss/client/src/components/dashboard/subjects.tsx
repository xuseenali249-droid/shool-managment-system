import { useQuery } from "@tanstack/react-query";
import { Book, DoorOpen, Calendar, Clock, Plus, Edit, Trash2, CalendarDays } from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { Subject, Class } from "@shared/schema";

interface ClassWithDetails extends Class {
  subject?: Subject;
  teacher?: {
    id: number;
    user?: {
      firstName: string;
      lastName: string;
    };
  };
}

export default function Subjects() {
  const { data: subjects, isLoading: subjectsLoading } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const { data: classes, isLoading: classesLoading } = useQuery<ClassWithDetails[]>({
    queryKey: ["/api/classes"],
  });

  const isLoading = subjectsLoading || classesLoading;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const totalSubjects = subjects?.length || 0;
  const activeClasses = classes?.filter(c => c.isActive).length || 0;
  const scheduledToday = Math.floor(activeClasses * 0.43); // ~43% of classes today
  const totalHoursPerWeek = activeClasses * 6; // Assume 6 hours per class per week

  const parseSchedule = (scheduleStr: string) => {
    try {
      const schedule = JSON.parse(scheduleStr);
      return Array.isArray(schedule) ? schedule : [];
    } catch {
      return [];
    }
  };

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Subjects Management</h2>
        <p className="text-gray-600">Manage course catalog, subjects, and class schedules</p>
      </div>

      {/* Subject Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard
          title="Total Subjects"
          value={totalSubjects}
          icon={Book}
          iconColor="text-primary"
        />
        <StatsCard
          title="Active Classes"
          value={activeClasses}
          icon={DoorOpen}
          iconColor="text-success"
        />
        <StatsCard
          title="Scheduled Today"
          value={scheduledToday}
          icon={Calendar}
          iconColor="text-warning"
        />
        <StatsCard
          title="Total Hours/Week"
          value={totalHoursPerWeek}
          icon={Clock}
          iconColor="text-secondary"
        />
      </div>

      {/* Subjects Management */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">
              Subjects & Schedule
            </CardTitle>
            <div className="flex space-x-3">
              <Button variant="outline" size="sm">
                <CalendarDays className="mr-2 h-4 w-4" />
                View Schedule
              </Button>
              <Button className="bg-primary hover:bg-primary/90" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Subject
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="font-medium text-gray-500">Subject</TableHead>
                  <TableHead className="font-medium text-gray-500">Teacher</TableHead>
                  <TableHead className="font-medium text-gray-500">Grade</TableHead>
                  <TableHead className="font-medium text-gray-500">Schedule</TableHead>
                  <TableHead className="font-medium text-gray-500">Status</TableHead>
                  <TableHead className="font-medium text-gray-500">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {classes?.map((classItem) => {
                  const schedule = parseSchedule(classItem.schedule || "[]");
                  const scheduleDisplay = schedule.length > 0 
                    ? `${schedule.map((s: any) => `${s.day} ${s.time}`).join(", ")}`
                    : "Not scheduled";

                  return (
                    <TableRow key={classItem.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Book className="text-primary h-5 w-5" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {classItem.subject?.name || "Unknown Subject"}
                            </div>
                            <div className="text-sm text-gray-500">
                              {classItem.subject?.description || classItem.subject?.code}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        {classItem.teacher?.user 
                          ? `${classItem.teacher.user.firstName} ${classItem.teacher.user.lastName}`
                          : "Unassigned"
                        }
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        {classItem.grade}-{classItem.section}
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        <div className="max-w-48 truncate" title={scheduleDisplay}>
                          {scheduleDisplay}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={classItem.isActive ? "default" : "secondary"}>
                          {classItem.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-800">
                            <CalendarDays className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
