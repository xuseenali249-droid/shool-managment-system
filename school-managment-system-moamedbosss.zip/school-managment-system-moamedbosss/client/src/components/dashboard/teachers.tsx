import { useQuery } from "@tanstack/react-query";
import { BookOpen, UserCheck, CalendarX, UserPlus, Plus, Eye, Edit, UserMinus, Filter } from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface TeacherWithUser {
  id: number;
  userId: number;
  employeeId: string;
  department: string;
  subject: string;
  qualification?: string;
  experience?: number;
  phone?: string;
  hireDate: Date;
  user?: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    isActive: boolean;
  };
}

export default function Teachers() {
  const { data: teachers, isLoading } = useQuery<TeacherWithUser[]>({
    queryKey: ["/api/teachers"],
  });

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString();
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-xl h-32"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const totalTeachers = teachers?.length || 0;
  const activeToday = teachers?.filter(t => t.user?.isActive).length || 0;
  const onLeave = Math.floor(totalTeachers * 0.05); // 5% assumed on leave
  const newThisMonth = Math.floor(totalTeachers * 0.03); // 3% assumed new

  return (
    <div className="space-y-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Teachers Management</h2>
        <p className="text-gray-600">Manage teacher profiles, assignments, and schedules</p>
      </div>

      {/* Teacher Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard
          title="Total Teachers"
          value={totalTeachers}
          icon={BookOpen}
          iconColor="text-secondary"
        />
        <StatsCard
          title="Active Today"
          value={activeToday}
          icon={UserCheck}
          iconColor="text-success"
        />
        <StatsCard
          title="On Leave"
          value={onLeave}
          icon={CalendarX}
          iconColor="text-warning"
        />
        <StatsCard
          title="New This Month"
          value={newThisMonth}
          icon={UserPlus}
          iconColor="text-primary"
        />
      </div>

      {/* Teachers Directory */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">
              Teachers Directory
            </CardTitle>
            <div className="flex space-x-3">
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button className="bg-primary hover:bg-primary/90" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Teacher
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="font-medium text-gray-500">Teacher</TableHead>
                  <TableHead className="font-medium text-gray-500">Subject</TableHead>
                  <TableHead className="font-medium text-gray-500">Department</TableHead>
                  <TableHead className="font-medium text-gray-500">Experience</TableHead>
                  <TableHead className="font-medium text-gray-500">Status</TableHead>
                  <TableHead className="font-medium text-gray-500">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {teachers?.map((teacher) => (
                  <TableRow key={teacher.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                          <span className="text-white font-medium text-sm">
                            {teacher.user?.firstName[0]}{teacher.user?.lastName[0]}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {teacher.user?.firstName} {teacher.user?.lastName}
                          </div>
                          <div className="text-sm text-gray-500">
                            {teacher.user?.email}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      {teacher.subject}
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      {teacher.department}
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">
                      {teacher.experience || 0} years
                    </TableCell>
                    <TableCell>
                      <Badge variant={teacher.user?.isActive ? "default" : "secondary"}>
                        {teacher.user?.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-800">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
