import { apiRequest } from "./queryClient";
import type { LoginData, User } from "@shared/schema";

export async function login(credentials: LoginData): Promise<User> {
  const response = await apiRequest("POST", "/api/login", credentials);
  const data = await response.json();
  return data.user;
}

export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/logout");
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const response = await apiRequest("GET", "/api/auth/user");
    return await response.json();
  } catch (error) {
    if (error instanceof Error && error.message.includes("401")) {
      return null;
    }
    throw error;
  }
}
