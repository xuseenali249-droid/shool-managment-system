import { apiRequest } from "./queryClient";

export interface NotionStatus {
  connected: boolean;
  error?: string;
}

export interface NotionDatabase {
  id: string;
  title: string;
}

export interface SyncResult {
  success: boolean;
  message?: string;
  syncedCount?: number;
  error?: string;
}

export async function checkNotionStatus(): Promise<NotionStatus> {
  return apiRequest("/api/notion/status");
}

export async function setupNotionDatabases(): Promise<SyncResult> {
  return apiRequest("/api/notion/setup", {
    method: "POST",
  });
}

export async function syncStudentsToNotion(): Promise<SyncResult> {
  return apiRequest("/api/notion/sync/students", {
    method: "POST",
  });
}

export async function syncTeachersToNotion(): Promise<SyncResult> {
  return apiRequest("/api/notion/sync/teachers", {
    method: "POST",
  });
}

export async function getNotionDatabases(): Promise<{ databases: NotionDatabase[] }> {
  return apiRequest("/api/notion/databases");
}