import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { 
  GraduationCap, Search, Bell, ChevronDown, BarChart3, 
  Users, BookOpen, Calendar, DollarSign, Settings, LogOut,
  User as UserIcon, Database, FileText, Brain
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import Overview from "@/components/dashboard/overview";
import Administration from "@/components/dashboard/administration";
import Teachers from "@/components/dashboard/teachers";
import Students from "@/components/dashboard/students";
import Attendance from "@/components/dashboard/attendance";
import Subjects from "@/components/dashboard/subjects";
import Financial from "@/components/dashboard/financial";
import NotionIntegration from "@/components/dashboard/notion";
import Reports from "@/components/dashboard/reports";
import ResearchAI from "@/components/dashboard/research-ai";

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const params = useParams();
  const [activeModule, setActiveModule] = useState(params.module || "overview");

  useEffect(() => {
    if (params.module) {
      setActiveModule(params.module);
    }
  }, [params.module]);

  const navigationItems = [
    { id: "overview", label: "Dashboard", icon: BarChart3 },
    { id: "administration", label: "Administration", icon: Users },
    { id: "teachers", label: "Teachers", icon: BookOpen },
    { id: "students", label: "Students", icon: UserIcon },
    { id: "attendance", label: "Attendance", icon: Calendar },
    { id: "subjects", label: "Subjects", icon: BookOpen },
    { id: "financial", label: "Financial", icon: DollarSign },
    { id: "reports", label: "Reports", icon: FileText },
    { id: "research-ai", label: "Research & AI", icon: Brain },
    { id: "notion", label: "Notion", icon: Database },
  ];

  const renderModule = () => {
    switch (activeModule) {
      case "administration":
        return <Administration />;
      case "teachers":
        return <Teachers />;
      case "students":
        return <Students />;
      case "attendance":
        return <Attendance />;
      case "subjects":
        return <Subjects />;
      case "financial":
        return <Financial />;
      case "reports":
        return <Reports />;
      case "research-ai":
        return <ResearchAI />;
      case "notion":
        return <NotionIntegration />;
      default:
        return <Overview />;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b border-gray-200/50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-primary mr-3" />
              <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">EduManage Pro</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search..."
                  className="w-64 pl-10"
                />
              </div>
              
              {/* Notifications */}
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5 text-gray-600" />
                <span className="absolute -top-1 -right-1 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  3
                </span>
              </Button>

              {/* User Menu */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {user.username ? user.username[0].toUpperCase() : 'U'}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">
                    {user.username || 'User'}
                  </p>
                  <p className="text-xs text-gray-500 capitalize">{user.role || 'admin'}</p>
                </div>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4 text-gray-600" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white/80 backdrop-blur-sm shadow-lg min-h-screen border-r border-gray-200/50">
          <div className="p-6">
            {/* Overview */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                Overview
              </h3>
              <Button
                variant={activeModule === "overview" ? "default" : "ghost"}
                className={`w-full justify-start transition-all duration-200 rounded-xl ${
                  activeModule === "overview" 
                    ? "bg-gradient-to-r from-primary to-accent text-white shadow-lg scale-105" 
                    : "hover:bg-gradient-to-r hover:from-gray-50 hover:to-blue-50"
                }`}
                onClick={() => setActiveModule("overview")}
              >
                <BarChart3 className="mr-3 h-4 w-4" />
                Dashboard
              </Button>
            </div>

            {/* Management Modules */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                Management
              </h3>
              <div className="space-y-1">
                {navigationItems.slice(1).map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={activeModule === item.id ? "default" : "ghost"}
                      className={`w-full justify-start transition-all duration-200 rounded-xl ${
                        activeModule === item.id 
                          ? "bg-gradient-to-r from-primary to-accent text-white shadow-lg scale-105" 
                          : "hover:bg-gradient-to-r hover:from-gray-50 hover:to-blue-50"
                      }`}
                      onClick={() => setActiveModule(item.id)}
                    >
                      <Icon className="mr-3 h-4 w-4" />
                      {item.label}
                    </Button>
                  );
                })}
              </div>
            </div>

            {/* System */}
            <div>
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                System
              </h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start">
                  <Settings className="mr-3 h-4 w-4" />
                  Settings
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start"
                  onClick={logout}
                >
                  <LogOut className="mr-3 h-4 w-4" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-lg border border-white/20 p-8 min-h-[calc(100vh-12rem)]">
            {renderModule()}
          </div>
        </main>
      </div>
    </div>
  );
}
