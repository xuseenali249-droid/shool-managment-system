import { useEffect, useState } from "react";
import { GraduationCap } from "lucide-react";

export default function SplashScreen() {
  const [dots, setDots] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setDots((prev) => (prev + 1) % 4);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-primary to-blue-800 flex items-center justify-center z-50">
      <div className="text-center text-white">
        <div className="mb-8">
          <GraduationCap className="h-20 w-20 mx-auto mb-4 animate-pulse" />
          <h1 className="text-4xl font-bold mb-2">EduManage Pro</h1>
          <p className="text-xl opacity-90">School Management System</p>
        </div>
        
        <div className="flex items-center justify-center space-x-2 mb-4">
          {[0, 1, 2].map((index) => (
            <div
              key={index}
              className={`w-3 h-3 bg-white rounded-full loading-dot`}
              style={{ animationDelay: `${index * 0.1}s` }}
            />
          ))}
        </div>
        
        <p className="text-sm opacity-75">
          Loading system{".".repeat(dots)}
        </p>
      </div>
    </div>
  );
}
