import { Client } from "@notionhq/client";

// Initialize Notion client
export const notion = new Client({
    auth: process.env.NOTION_INTEGRATION_SECRET!,
});

// Extract the page ID from the Notion page URL
function extractPageIdFromUrl(pageUrl: string): string {
    // Handle different Notion URL formats
    // Format 1: https://www.notion.so/username/Page-Name-32charID
    // Format 2: https://notion.so/32charID
    // Format 3: https://www.notion.so/32charID
    
    // First try to extract 32-character hex ID
    let match = pageUrl.match(/([a-f0-9]{32})(?:[?#]|$)/i);
    if (match && match[1]) {
        return match[1];
    }
    
    // Try extracting from UUID format with dashes
    match = pageUrl.match(/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i);
    if (match && match[1]) {
        return match[1].replace(/-/g, '');
    }
    
    // Try extracting from the end of the URL
    match = pageUrl.match(/([a-f0-9]{32})/i);
    if (match && match[1]) {
        return match[1];
    }

    console.error("Could not extract page ID from URL:", pageUrl);
    throw Error("Failed to extract page ID from URL. Please ensure the URL is a valid Notion page URL.");
}

export const NOTION_PAGE_ID = (() => {
  try {
    return process.env.NOTION_PAGE_URL ? extractPageIdFromUrl(process.env.NOTION_PAGE_URL) : null;
  } catch (error) {
    console.warn("Invalid NOTION_PAGE_URL provided. Please provide a valid Notion page URL.");
    return null;
  }
})();

/**
 * Lists all child databases contained within NOTION_PAGE_ID
 */
export async function getNotionDatabases() {
    const childDatabases = [];

    try {
        let hasMore = true;
        let startCursor: string | undefined = undefined;

        while (hasMore) {
            const response = await notion.blocks.children.list({
                block_id: NOTION_PAGE_ID,
                start_cursor: startCursor,
            });

            for (const block of response.results) {
                if (block.type === "child_database") {
                    const databaseId = block.id;

                    try {
                        const databaseInfo = await notion.databases.retrieve({
                            database_id: databaseId,
                        });

                        childDatabases.push(databaseInfo);
                    } catch (error) {
                        console.error(`Error retrieving database ${databaseId}:`, error);
                    }
                }
            }

            hasMore = response.has_more;
            startCursor = response.next_cursor || undefined;
        }

        return childDatabases;
    } catch (error) {
        console.error("Error listing child databases:", error);
        throw error;
    }
}

// Find a Notion database with the matching title
export async function findDatabaseByTitle(title: string) {
    const databases = await getNotionDatabases();

    for (const db of databases) {
        if (db.title && Array.isArray(db.title) && db.title.length > 0) {
            const dbTitle = db.title[0]?.plain_text?.toLowerCase() || "";
            if (dbTitle === title.toLowerCase()) {
                return db;
            }
        }
    }

    return null;
}

// Create a new database if one with a matching title does not exist
export async function createDatabaseIfNotExists(title: string, properties: any) {
    const existingDb = await findDatabaseByTitle(title);
    if (existingDb) {
        return existingDb;
    }
    return await notion.databases.create({
        parent: {
            type: "page_id",
            page_id: NOTION_PAGE_ID
        },
        title: [
            {
                type: "text",
                text: {
                    content: title
                }
            }
        ],
        properties
    });
}

// Get all students from the Notion database
export async function getStudentsFromNotion(studentsDatabaseId: string) {
    try {
        const response = await notion.databases.query({
            database_id: studentsDatabaseId,
        });

        return response.results.map((page: any) => {
            const properties = page.properties;

            return {
                notionId: page.id,
                studentId: properties.StudentID?.rich_text?.[0]?.plain_text || "",
                name: properties.Name?.title?.[0]?.plain_text || "Untitled Student",
                grade: properties.Grade?.select?.name || "",
                section: properties.Section?.select?.name || "",
                email: properties.Email?.email || null,
                phone: properties.Phone?.phone_number || null,
                guardianName: properties.GuardianName?.rich_text?.[0]?.plain_text || "",
                guardianPhone: properties.GuardianPhone?.phone_number || null,
                enrollmentDate: properties.EnrollmentDate?.date?.start
                    ? new Date(properties.EnrollmentDate.date.start)
                    : null,
                status: properties.Status?.select?.name || "Active",
            };
        });
    } catch (error) {
        console.error("Error fetching students from Notion:", error);
        throw new Error("Failed to fetch students from Notion");
    }
}

// Get all teachers from the Notion database
export async function getTeachersFromNotion(teachersDatabaseId: string) {
    try {
        const response = await notion.databases.query({
            database_id: teachersDatabaseId,
        });

        return response.results.map((page: any) => {
            const properties = page.properties;

            return {
                notionId: page.id,
                employeeId: properties.EmployeeID?.rich_text?.[0]?.plain_text || "",
                name: properties.Name?.title?.[0]?.plain_text || "Untitled Teacher",
                department: properties.Department?.select?.name || "",
                subject: properties.Subject?.multi_select?.map((s: any) => s.name).join(", ") || "",
                email: properties.Email?.email || null,
                phone: properties.Phone?.phone_number || null,
                qualification: properties.Qualification?.rich_text?.[0]?.plain_text || null,
                experience: properties.Experience?.number || null,
                hireDate: properties.HireDate?.date?.start
                    ? new Date(properties.HireDate.date.start)
                    : null,
                status: properties.Status?.select?.name || "Active",
            };
        });
    } catch (error) {
        console.error("Error fetching teachers from Notion:", error);
        throw new Error("Failed to fetch teachers from Notion");
    }
}

// Create a new student in Notion
export async function createStudentInNotion(studentsDatabaseId: string, studentData: any) {
    try {
        return await notion.pages.create({
            parent: {
                database_id: studentsDatabaseId
            },
            properties: {
                Name: {
                    title: [
                        {
                            text: {
                                content: `${studentData.firstName} ${studentData.lastName}`
                            }
                        }
                    ]
                },
                StudentID: {
                    rich_text: [
                        {
                            text: {
                                content: studentData.studentId
                            }
                        }
                    ]
                },
                Grade: {
                    select: {
                        name: studentData.grade
                    }
                },
                Section: {
                    select: {
                        name: studentData.section
                    }
                },
                Email: {
                    email: studentData.email || null
                },
                Phone: {
                    phone_number: studentData.phone || null
                },
                GuardianName: {
                    rich_text: [
                        {
                            text: {
                                content: studentData.guardianName || ""
                            }
                        }
                    ]
                },
                GuardianPhone: {
                    phone_number: studentData.guardianPhone || null
                },
                EnrollmentDate: {
                    date: {
                        start: studentData.enrollmentDate?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0]
                    }
                },
                Status: {
                    select: {
                        name: "Active"
                    }
                }
            }
        });
    } catch (error) {
        console.error("Error creating student in Notion:", error);
        throw error;
    }
}

// Create a new teacher in Notion
export async function createTeacherInNotion(teachersDatabaseId: string, teacherData: any) {
    try {
        return await notion.pages.create({
            parent: {
                database_id: teachersDatabaseId
            },
            properties: {
                Name: {
                    title: [
                        {
                            text: {
                                content: `${teacherData.firstName} ${teacherData.lastName}`
                            }
                        }
                    ]
                },
                EmployeeID: {
                    rich_text: [
                        {
                            text: {
                                content: teacherData.employeeId
                            }
                        }
                    ]
                },
                Department: {
                    select: {
                        name: teacherData.department
                    }
                },
                Subject: {
                    multi_select: teacherData.subject.split(',').map((s: string) => ({ name: s.trim() }))
                },
                Email: {
                    email: teacherData.email || null
                },
                Phone: {
                    phone_number: teacherData.phone || null
                },
                Qualification: {
                    rich_text: [
                        {
                            text: {
                                content: teacherData.qualification || ""
                            }
                        }
                    ]
                },
                Experience: {
                    number: teacherData.experience || null
                },
                HireDate: {
                    date: {
                        start: teacherData.hireDate?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0]
                    }
                },
                Status: {
                    select: {
                        name: "Active"
                    }
                }
            }
        });
    } catch (error) {
        console.error("Error creating teacher in Notion:", error);
        throw error;
    }
}