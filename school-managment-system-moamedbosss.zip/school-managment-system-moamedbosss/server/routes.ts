import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import notionRoutes from "./routes/notion";
import reportsRoutes from "./routes/reports";
import aiRoutes from "./routes/ai";

// Extend Express Request type to include session
declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number;
      username: string;
      role: string;
    };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  const memoryStoreConstructor = MemoryStore(session);
  
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    store: new memoryStoreConstructor({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      secure: false, // set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session?.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  const requireRole = (role: string) => (req: any, res: any, next: any) => {
    if (!req.session?.user || req.session.user.role !== role) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };

  // Auth routes
  app.post('/api/login', async (req, res) => {
    try {
      console.log('Login attempt:', req.body);
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      console.log('User found:', user ? 'Yes' : 'No');
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      if (!user.isActive) {
        return res.status(401).json({ message: "Account is disabled" });
      }

      req.session!.user = {
        id: user.id,
        username: user.username,
        role: user.role
      };
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      console.error('Login error:', error);
      res.status(400).json({ message: "Invalid request data", error: error.message });
    }
  });

  app.post('/api/logout', (req, res) => {
    req.session!.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/auth/user', (req, res) => {
    if (req.session?.user) {
      res.json(req.session.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // Notion integration routes
  app.get('/api/notion/status', async (req, res) => {
    try {
      const hasSecret = !!process.env.NOTION_INTEGRATION_SECRET;
      const hasPageUrl = !!process.env.NOTION_PAGE_URL;
      
      if (hasSecret && hasPageUrl) {
        // Test connection
        const { notion, NOTION_PAGE_ID } = await import('./notion');
        if (NOTION_PAGE_ID) {
          try {
            await notion.pages.retrieve({ page_id: NOTION_PAGE_ID });
            res.json({ status: 'connected', hasSecret, hasPageUrl });
          } catch (error) {
            res.json({ status: 'error', hasSecret, hasPageUrl, error: 'Invalid page or insufficient permissions' });
          }
        } else {
          res.json({ status: 'error', hasSecret, hasPageUrl, error: 'Invalid page URL format' });
        }
      } else {
        res.json({ status: 'not_configured', hasSecret, hasPageUrl });
      }
    } catch (error) {
      res.json({ status: 'error', error: error.message });
    }
  });

  app.post('/api/notion/setup', async (req, res) => {
    try {
      if (!process.env.NOTION_INTEGRATION_SECRET || !process.env.NOTION_PAGE_URL) {
        return res.status(400).json({ message: 'Notion credentials not configured' });
      }

      const { createDatabaseIfNotExists, NOTION_PAGE_ID } = await import('./notion');
      
      if (!NOTION_PAGE_ID) {
        return res.status(400).json({ message: 'Invalid Notion page URL' });
      }

      // Create databases
      const studentsDb = await createDatabaseIfNotExists("Students", {
        Name: { title: {} },
        StudentID: { rich_text: {} },
        Grade: { select: { options: [
          { name: "9", color: "blue" }, { name: "10", color: "green" },
          { name: "11", color: "orange" }, { name: "12", color: "purple" }
        ]}},
        Section: { select: { options: [
          { name: "A", color: "blue" }, { name: "B", color: "green" },
          { name: "C", color: "orange" }, { name: "D", color: "purple" }
        ]}},
        Email: { email: {} },
        GuardianName: { rich_text: {} },
        GuardianPhone: { phone_number: {} },
        Status: { select: { options: [
          { name: "Active", color: "green" }, { name: "Inactive", color: "red" }
        ]}}
      });

      const teachersDb = await createDatabaseIfNotExists("Teachers", {
        Name: { title: {} },
        EmployeeID: { rich_text: {} },
        Department: { select: { options: [
          { name: "Mathematics", color: "blue" }, { name: "Science", color: "green" },
          { name: "English", color: "orange" }, { name: "History", color: "purple" }
        ]}},
        Email: { email: {} },
        Phone: { phone_number: {} },
        Status: { select: { options: [
          { name: "Active", color: "green" }, { name: "Inactive", color: "red" }
        ]}}
      });

      res.json({ 
        message: 'Notion databases created successfully',
        databases: { studentsDb: studentsDb.id, teachersDb: teachersDb.id }
      });
    } catch (error) {
      console.error('Notion setup error:', error);
      res.status(500).json({ message: 'Failed to setup Notion databases', error: error.message });
    }
  });

  app.get('/api/notion/sync/students', requireAuth, async (req, res) => {
    try {
      const { findDatabaseByTitle, getStudentsFromNotion } = await import('./notion');
      
      const studentsDb = await findDatabaseByTitle("Students");
      if (!studentsDb) {
        return res.status(404).json({ message: 'Students database not found in Notion' });
      }

      const notionStudents = await getStudentsFromNotion(studentsDb.id);
      res.json(notionStudents);
    } catch (error) {
      console.error('Error syncing students from Notion:', error);
      res.status(500).json({ message: 'Failed to sync students from Notion', error: error.message });
    }
  });

  app.get('/api/notion/sync/teachers', requireAuth, async (req, res) => {
    try {
      const { findDatabaseByTitle, getTeachersFromNotion } = await import('./notion');
      
      const teachersDb = await findDatabaseByTitle("Teachers");
      if (!teachersDb) {
        return res.status(404).json({ message: 'Teachers database not found in Notion' });
      }

      const notionTeachers = await getTeachersFromNotion(teachersDb.id);
      res.json(notionTeachers);
    } catch (error) {
      console.error('Error syncing teachers from Notion:', error);
      res.status(500).json({ message: 'Failed to sync teachers from Notion', error: error.message });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', requireAuth, async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      const teachers = await storage.getAllTeachers();
      const classes = await storage.getAllClasses();
      const fees = await storage.getAllFees();
      const payments = await storage.getAllPayments();

      const totalRevenue = payments.reduce((sum, payment) =>
        sum + parseFloat(payment.amount), 0);

      const pendingFees = fees.filter(fee => fee.status === 'pending');
      const pendingAmount = pendingFees.reduce((sum, fee) =>
        sum + parseFloat(fee.amount), 0);

      const overdueFees = fees.filter(fee => fee.status === 'overdue');
      const overdueAmount = overdueFees.reduce((sum, fee) =>
        sum + parseFloat(fee.amount), 0);

      const stats = {
        totalStudents: students.length,
        totalTeachers: teachers.length,
        activeClasses: classes.filter(c => c.isActive).length,
        monthlyRevenue: totalRevenue,
        pendingAmount,
        overdueAmount,
        presentToday: Math.floor(students.length * 0.925), // 92.5% attendance
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Users management
  app.get('/api/users', requireAuth, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPassword = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/users', requireRole('admin'), async (req, res) => {
    try {
      const user = await storage.createUser(req.body);
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Failed to create user" });
    }
  });

  app.put('/api/users/:id', requireRole('admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.updateUser(id, req.body);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Failed to update user" });
    }
  });

  // Students management
  app.get('/api/students', requireAuth, async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      const studentsWithUsers = await Promise.all(
        students.map(async (student) => {
          const user = await storage.getUser(student.userId);
          return { ...student, user };
        })
      );
      res.json(studentsWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.post('/api/students', requireAuth, async (req, res) => {
    try {
      const student = await storage.createStudent(req.body);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ message: "Failed to create student" });
    }
  });

  app.put('/api/students/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.updateStudent(id, req.body);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(400).json({ message: "Failed to update student" });
    }
  });

  // Teachers management
  app.get('/api/teachers', requireAuth, async (req, res) => {
    try {
      const teachers = await storage.getAllTeachers();
      const teachersWithUsers = await Promise.all(
        teachers.map(async (teacher) => {
          const user = await storage.getUser(teacher.userId);
          return { ...teacher, user };
        })
      );
      res.json(teachersWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  app.post('/api/teachers', requireAuth, async (req, res) => {
    try {
      const teacher = await storage.createTeacher(req.body);
      res.status(201).json(teacher);
    } catch (error) {
      res.status(400).json({ message: "Failed to create teacher" });
    }
  });

  app.put('/api/teachers/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const teacher = await storage.updateTeacher(id, req.body);
      if (!teacher) {
        return res.status(404).json({ message: "Teacher not found" });
      }
      res.json(teacher);
    } catch (error) {
      res.status(400).json({ message: "Failed to update teacher" });
    }
  });

  // Subjects management
  app.get('/api/subjects', requireAuth, async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  app.post('/api/subjects', requireAuth, async (req, res) => {
    try {
      const subject = await storage.createSubject(req.body);
      res.status(201).json(subject);
    } catch (error) {
      res.status(400).json({ message: "Failed to create subject" });
    }
  });

  app.put('/api/subjects/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const subject = await storage.updateSubject(id, req.body);
      if (!subject) {
        return res.status(404).json({ message: "Subject not found" });
      }
      res.json(subject);
    } catch (error) {
      res.status(400).json({ message: "Failed to update subject" });
    }
  });

  // Classes management
  app.get('/api/classes', requireAuth, async (req, res) => {
    try {
      const classes = await storage.getAllClasses();
      const classesWithDetails = await Promise.all(
        classes.map(async (cls) => {
          const subject = await storage.getSubject(cls.subjectId);
          const teacher = await storage.getTeacher(cls.teacherId);
          const teacherUser = teacher ? await storage.getUser(teacher.userId) : null;
          return { 
            ...cls, 
            subject, 
            teacher: teacher ? { ...teacher, user: teacherUser } : null 
          };
        })
      );
      res.json(classesWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post('/api/classes', requireAuth, async (req, res) => {
    try {
      const classData = await storage.createClass(req.body);
      res.status(201).json(classData);
    } catch (error) {
      res.status(400).json({ message: "Failed to create class" });
    }
  });

  // Attendance management
  app.get('/api/attendance', requireAuth, async (req, res) => {
    try {
      const attendance = await storage.getAllAttendance();
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post('/api/attendance', requireAuth, async (req, res) => {
    try {
      const attendance = await storage.createAttendance(req.body);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(400).json({ message: "Failed to create attendance record" });
    }
  });

  app.get('/api/attendance/class/:classId', requireAuth, async (req, res) => {
    try {
      const classId = parseInt(req.params.classId);
      const date = req.query.date ? new Date(req.query.date as string) : undefined;
      const attendance = await storage.getAttendanceByClass(classId, date);
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch class attendance" });
    }
  });

  // Fees management
  app.get('/api/fees', requireAuth, async (req, res) => {
    try {
      const fees = await storage.getAllFees();
      const feesWithStudents = await Promise.all(
        fees.map(async (fee) => {
          const student = await storage.getStudent(fee.studentId);
          const user = student ? await storage.getUser(student.userId) : null;
          return { ...fee, student: student ? { ...student, user } : null };
        })
      );
      res.json(feesWithStudents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fees" });
    }
  });

  app.post('/api/fees', requireAuth, async (req, res) => {
    try {
      const fee = await storage.createFee(req.body);
      res.status(201).json(fee);
    } catch (error) {
      res.status(400).json({ message: "Failed to create fee" });
    }
  });

  app.put('/api/fees/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const fee = await storage.updateFee(id, req.body);
      if (!fee) {
        return res.status(404).json({ message: "Fee not found" });
      }
      res.json(fee);
    } catch (error) {
      res.status(400).json({ message: "Failed to update fee" });
    }
  });

  // Payments management
  app.get('/api/payments', requireAuth, async (req, res) => {
    try {
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.post('/api/payments', requireAuth, async (req, res) => {
    try {
      const payment = await storage.createPayment(req.body);
      // Update fee status to paid
      const fee = await storage.getFee(payment.feeId);
      if (fee) {
        await storage.updateFee(payment.feeId, { status: 'paid' });
      }
      res.status(201).json(payment);
    } catch (error) {
      res.status(400).json({ message: "Failed to create payment" });
    }
  });

  // Notion integration routes
  app.use("/api/notion", notionRoutes);

  // Reports routes
  app.use("/api/reports", reportsRoutes);

  // AI and Research routes
  app.use("/api/ai", aiRoutes);

  const httpServer = createServer(app);
  return httpServer;
}
