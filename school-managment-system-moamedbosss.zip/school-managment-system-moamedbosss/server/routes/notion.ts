import { Router } from "express";
import { notion, getNotionDatabases, findDatabaseByTitle, createDatabaseIfNotExists, getStudentsFromNotion, getTeachersFromNotion, createStudentInNotion, createTeacherInNotion } from "../notion";
import { storage } from "../storage";

const router = Router();

// Check Notion connection status
router.get("/status", async (req, res) => {
  try {
    if (!process.env.NOTION_INTEGRATION_SECRET || !process.env.NOTION_PAGE_URL) {
      return res.json({
        connected: false,
        error: "Missing Notion credentials"
      });
    }

    // Test connection by trying to list databases
    await getNotionDatabases();
    res.json({ connected: true });
  } catch (error) {
    console.error("Notion connection error:", error);
    res.json({
      connected: false,
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

// Setup Notion databases
router.post("/setup", async (req, res) => {
  try {
    // Create Students database
    const studentsDb = await createDatabaseIfNotExists("Students", {
      Name: { title: {} },
      Email: { email: {} },
      Grade: {
        select: {
          options: [
            { name: "1st Grade", color: "blue" },
            { name: "2nd Grade", color: "green" },
            { name: "3rd Grade", color: "yellow" },
            { name: "4th Grade", color: "orange" },
            { name: "5th Grade", color: "red" },
            { name: "6th Grade", color: "purple" },
            { name: "7th Grade", color: "pink" },
            { name: "8th Grade", color: "brown" },
            { name: "9th Grade", color: "gray" },
            { name: "10th Grade", color: "default" }
          ]
        }
      },
      Phone: { phone_number: {} },
      Address: { rich_text: {} },
      DateOfBirth: { date: {} },
      ParentName: { rich_text: {} },
      ParentPhone: { phone_number: {} },
      EnrollmentDate: { date: {} },
      Status: {
        select: {
          options: [
            { name: "Active", color: "green" },
            { name: "Inactive", color: "red" },
            { name: "Graduated", color: "blue" }
          ]
        }
      }
    });

    // Create Teachers database
    const teachersDb = await createDatabaseIfNotExists("Teachers", {
      Name: { title: {} },
      Email: { email: {} },
      Phone: { phone_number: {} },
      Subject: { multi_select: {
        options: [
          { name: "Mathematics", color: "blue" },
          { name: "English", color: "green" },
          { name: "Science", color: "yellow" },
          { name: "History", color: "orange" },
          { name: "Geography", color: "red" },
          { name: "Physical Education", color: "purple" },
          { name: "Art", color: "pink" },
          { name: "Music", color: "brown" }
        ]
      }},
      Qualification: { rich_text: {} },
      Experience: { number: {} },
      HireDate: { date: {} },
      Salary: { number: {} },
      Status: {
        select: {
          options: [
            { name: "Active", color: "green" },
            { name: "Inactive", color: "red" },
            { name: "On Leave", color: "yellow" }
          ]
        }
      }
    });

    // Create Attendance database
    await createDatabaseIfNotExists("Attendance", {
      StudentName: { relation: { database_id: studentsDb.id } },
      Date: { date: {} },
      Status: {
        select: {
          options: [
            { name: "Present", color: "green" },
            { name: "Absent", color: "red" },
            { name: "Late", color: "yellow" },
            { name: "Excused", color: "blue" }
          ]
        }
      },
      Notes: { rich_text: {} }
    });

    // Create Subjects database
    await createDatabaseIfNotExists("Subjects", {
      Name: { title: {} },
      Code: { rich_text: {} },
      Grade: {
        select: {
          options: [
            { name: "1st Grade", color: "blue" },
            { name: "2nd Grade", color: "green" },
            { name: "3rd Grade", color: "yellow" },
            { name: "4th Grade", color: "orange" },
            { name: "5th Grade", color: "red" },
            { name: "6th Grade", color: "purple" },
            { name: "7th Grade", color: "pink" },
            { name: "8th Grade", color: "brown" },
            { name: "9th Grade", color: "gray" },
            { name: "10th Grade", color: "default" }
          ]
        }
      },
      Teacher: { relation: { database_id: teachersDb.id } },
      Credits: { number: {} },
      Description: { rich_text: {} }
    });

    // Create Fees database
    await createDatabaseIfNotExists("Fees", {
      StudentName: { relation: { database_id: studentsDb.id } },
      FeeType: {
        select: {
          options: [
            { name: "Tuition", color: "blue" },
            { name: "Library", color: "green" },
            { name: "Lab", color: "yellow" },
            { name: "Sports", color: "orange" },
            { name: "Transport", color: "red" },
            { name: "Exam", color: "purple" }
          ]
        }
      },
      Amount: { number: {} },
      DueDate: { date: {} },
      Status: {
        select: {
          options: [
            { name: "Pending", color: "yellow" },
            { name: "Paid", color: "green" },
            { name: "Overdue", color: "red" },
            { name: "Partial", color: "orange" }
          ]
        }
      }
    });

    res.json({ 
      success: true, 
      message: "Notion databases created successfully",
      databases: {
        students: studentsDb.id,
        teachers: teachersDb.id
      }
    });
  } catch (error) {
    console.error("Notion setup error:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to setup Notion databases"
    });
  }
});

// Sync students to Notion
router.post("/sync/students", async (req, res) => {
  try {
    const studentsDb = await findDatabaseByTitle("Students");
    if (!studentsDb) {
      return res.status(400).json({ error: "Students database not found. Please run setup first." });
    }

    const students = await storage.getAllStudents();
    let syncedCount = 0;

    for (const student of students) {
      try {
        await createStudentInNotion(studentsDb.id, {
          name: student.name,
          email: student.email,
          grade: student.grade,
          phone: student.phone,
          address: student.address,
          dateOfBirth: student.dateOfBirth,
          parentName: student.parentName,
          parentPhone: student.parentPhone,
          enrollmentDate: student.enrollmentDate,
          status: "Active"
        });
        syncedCount++;
      } catch (error) {
        console.error(`Failed to sync student ${student.name}:`, error);
      }
    }

    res.json({
      success: true,
      message: `Synced ${syncedCount} students to Notion`,
      syncedCount
    });
  } catch (error) {
    console.error("Student sync error:", error);
    res.status(500).json({
      error: error instanceof Error ? error.message : "Failed to sync students"
    });
  }
});

// Sync teachers to Notion
router.post("/sync/teachers", async (req, res) => {
  try {
    const teachersDb = await findDatabaseByTitle("Teachers");
    if (!teachersDb) {
      return res.status(400).json({ error: "Teachers database not found. Please run setup first." });
    }

    const teachers = await storage.getAllTeachers();
    let syncedCount = 0;

    for (const teacher of teachers) {
      try {
        await createTeacherInNotion(teachersDb.id, {
          name: teacher.name,
          email: teacher.email,
          phone: teacher.phone,
          subject: teacher.subject,
          qualification: teacher.qualification,
          experience: teacher.experience,
          hireDate: teacher.hireDate,
          salary: teacher.salary,
          status: "Active"
        });
        syncedCount++;
      } catch (error) {
        console.error(`Failed to sync teacher ${teacher.name}:`, error);
      }
    }

    res.json({
      success: true,
      message: `Synced ${syncedCount} teachers to Notion`,
      syncedCount
    });
  } catch (error) {
    console.error("Teacher sync error:", error);
    res.status(500).json({
      error: error instanceof Error ? error.message : "Failed to sync teachers"
    });
  }
});

// Get all databases
router.get("/databases", async (req, res) => {
  try {
    const databases = await getNotionDatabases();
    res.json({ databases });
  } catch (error) {
    console.error("Error fetching databases:", error);
    res.status(500).json({
      error: error instanceof Error ? error.message : "Failed to fetch databases"
    });
  }
});

export default router;