import { Router } from "express";
import { storage } from "../storage";

const router = Router();

// Generate comprehensive school report
router.get("/overview", async (req, res) => {
  try {
    const [students, teachers, attendance, fees, payments] = await Promise.all([
      storage.getAllStudents(),
      storage.getAllTeachers(),
      storage.getAllAttendance(),
      storage.getAllFees(),
      storage.getAllPayments()
    ]);

    // Calculate statistics
    const totalStudents = students.length;
    const totalTeachers = teachers.length;
    const totalRevenue = payments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
    const pendingFees = fees.filter(fee => fee.status === 'pending');
    const overdueFees = fees.filter(fee => fee.status === 'overdue');
    
    // Student distribution by grade
    const studentsByGrade = students.reduce((acc, student) => {
      acc[student.grade] = (acc[student.grade] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Teacher distribution by department
    const teachersByDepartment = teachers.reduce((acc, teacher) => {
      acc[teacher.department] = (acc[teacher.department] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Fee collection status
    const feesByStatus = fees.reduce((acc, fee) => {
      acc[fee.status] = (acc[fee.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Monthly revenue trend (simplified)
    const monthlyRevenue = payments
      .filter(payment => {
        const paymentDate = new Date(payment.paidAt);
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        return paymentDate.getMonth() === currentMonth && paymentDate.getFullYear() === currentYear;
      })
      .reduce((sum, payment) => sum + parseFloat(payment.amount), 0);

    const report = {
      summary: {
        totalStudents,
        totalTeachers,
        totalRevenue: totalRevenue.toFixed(2),
        monthlyRevenue: monthlyRevenue.toFixed(2),
        pendingAmount: pendingFees.reduce((sum, fee) => sum + parseFloat(fee.amount), 0).toFixed(2),
        overdueAmount: overdueFees.reduce((sum, fee) => sum + parseFloat(fee.amount), 0).toFixed(2),
        attendanceRate: attendance.length > 0 ? 
          ((attendance.filter(a => a.status === 'present').length / attendance.length) * 100).toFixed(1) : '0'
      },
      distributions: {
        studentsByGrade,
        teachersByDepartment,
        feesByStatus
      },
      recentActivity: {
        recentEnrollments: students.slice(-5),
        recentPayments: payments.slice(-5),
        upcomingDueDates: fees
          .filter(fee => fee.status === 'pending')
          .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
          .slice(0, 5)
      }
    };

    res.json(report);
  } catch (error) {
    console.error("Error generating overview report:", error);
    res.status(500).json({ message: "Failed to generate overview report" });
  }
});

// Student performance report
router.get("/students", async (req, res) => {
  try {
    const { grade, section } = req.query;
    
    let students = await storage.getAllStudents();
    
    if (grade) {
      students = students.filter(student => student.grade === grade);
    }
    
    if (section) {
      students = students.filter(student => student.section === section);
    }

    // Get attendance data for students
    const attendance = await storage.getAllAttendance();
    const fees = await storage.getAllFees();

    const studentReport = students.map(student => {
      const studentAttendance = attendance.filter(a => a.studentId === student.id);
      const studentFees = fees.filter(f => f.studentId === student.id);
      
      const attendanceRate = studentAttendance.length > 0 ? 
        ((studentAttendance.filter(a => a.status === 'present').length / studentAttendance.length) * 100).toFixed(1) : '0';
      
      const totalFees = studentFees.reduce((sum, fee) => sum + parseFloat(fee.amount), 0);
      const paidFees = studentFees.filter(fee => fee.status === 'paid').reduce((sum, fee) => sum + parseFloat(fee.amount), 0);
      const outstandingFees = totalFees - paidFees;

      return {
        ...student,
        attendanceRate,
        totalFees: totalFees.toFixed(2),
        paidFees: paidFees.toFixed(2),
        outstandingFees: outstandingFees.toFixed(2),
        feeStatus: outstandingFees > 0 ? 'pending' : 'paid'
      };
    });

    res.json({
      students: studentReport,
      summary: {
        totalStudents: studentReport.length,
        averageAttendance: studentReport.reduce((sum, s) => sum + parseFloat(s.attendanceRate), 0) / studentReport.length || 0,
        totalOutstanding: studentReport.reduce((sum, s) => sum + parseFloat(s.outstandingFees), 0).toFixed(2)
      }
    });
  } catch (error) {
    console.error("Error generating student report:", error);
    res.status(500).json({ message: "Failed to generate student report" });
  }
});

// Teacher performance report
router.get("/teachers", async (req, res) => {
  try {
    const teachers = await storage.getAllTeachers();
    const classes = await storage.getAllClasses();
    
    const teacherReport = teachers.map(teacher => {
      const teacherClasses = classes.filter(c => c.teacherId === teacher.id);
      
      return {
        ...teacher,
        totalClasses: teacherClasses.length,
        subjects: [...new Set(teacherClasses.map(c => c.grade))].join(', '),
        workload: teacherClasses.length > 5 ? 'High' : teacherClasses.length > 2 ? 'Medium' : 'Low'
      };
    });

    res.json({
      teachers: teacherReport,
      summary: {
        totalTeachers: teacherReport.length,
        averageExperience: teacherReport.reduce((sum, t) => sum + (t.experience || 0), 0) / teacherReport.length || 0,
        departmentDistribution: teacherReport.reduce((acc, teacher) => {
          acc[teacher.department] = (acc[teacher.department] || 0) + 1;
          return acc;
        }, {} as Record<string, number>)
      }
    });
  } catch (error) {
    console.error("Error generating teacher report:", error);
    res.status(500).json({ message: "Failed to generate teacher report" });
  }
});

// Financial report
router.get("/financial", async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const fees = await storage.getAllFees();
    const payments = await storage.getAllPayments();
    
    let filteredPayments = payments;
    
    if (startDate && endDate) {
      filteredPayments = payments.filter(payment => {
        const paymentDate = new Date(payment.paidAt);
        return paymentDate >= new Date(startDate as string) && paymentDate <= new Date(endDate as string);
      });
    }

    const totalRevenue = filteredPayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
    const pendingFees = fees.filter(fee => fee.status === 'pending');
    const overdueFees = fees.filter(fee => fee.status === 'overdue');
    const paidFees = fees.filter(fee => fee.status === 'paid');

    // Revenue by fee type
    const revenueByType = filteredPayments.reduce((acc, payment) => {
      const fee = fees.find(f => f.id === payment.feeId);
      if (fee) {
        acc[fee.feeType] = (acc[fee.feeType] || 0) + parseFloat(payment.amount);
      }
      return acc;
    }, {} as Record<string, number>);

    // Monthly revenue trend
    const monthlyRevenue = Array.from({ length: 12 }, (_, i) => {
      const month = i;
      const monthPayments = filteredPayments.filter(payment => {
        const paymentDate = new Date(payment.paidAt);
        return paymentDate.getMonth() === month;
      });
      return {
        month: new Date(2024, month).toLocaleString('default', { month: 'long' }),
        revenue: monthPayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0)
      };
    });

    res.json({
      summary: {
        totalRevenue: totalRevenue.toFixed(2),
        pendingAmount: pendingFees.reduce((sum, fee) => sum + parseFloat(fee.amount), 0).toFixed(2),
        overdueAmount: overdueFees.reduce((sum, fee) => sum + parseFloat(fee.amount), 0).toFixed(2),
        collectionRate: ((paidFees.length / fees.length) * 100).toFixed(1)
      },
      revenueByType,
      monthlyRevenue,
      recentTransactions: filteredPayments.slice(-10),
      upcomingDues: pendingFees
        .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
        .slice(0, 10)
    });
  } catch (error) {
    console.error("Error generating financial report:", error);
    res.status(500).json({ message: "Failed to generate financial report" });
  }
});

// Attendance report
router.get("/attendance", async (req, res) => {
  try {
    const { date, grade, section } = req.query;
    
    let attendance = await storage.getAllAttendance();
    
    if (date) {
      attendance = attendance.filter(a => {
        const attendanceDate = new Date(a.date).toDateString();
        const filterDate = new Date(date as string).toDateString();
        return attendanceDate === filterDate;
      });
    }

    const students = await storage.getAllStudents();
    
    // Filter students by grade/section if specified
    let filteredStudents = students;
    if (grade) filteredStudents = filteredStudents.filter(s => s.grade === grade);
    if (section) filteredStudents = filteredStudents.filter(s => s.section === section);

    const attendanceReport = filteredStudents.map(student => {
      const studentAttendance = attendance.filter(a => a.studentId === student.id);
      const totalDays = studentAttendance.length;
      const presentDays = studentAttendance.filter(a => a.status === 'present').length;
      const absentDays = studentAttendance.filter(a => a.status === 'absent').length;
      const lateDays = studentAttendance.filter(a => a.status === 'late').length;
      
      return {
        ...student,
        totalDays,
        presentDays,
        absentDays,
        lateDays,
        attendanceRate: totalDays > 0 ? ((presentDays / totalDays) * 100).toFixed(1) : '0'
      };
    });

    // Daily attendance summary
    const dailyAttendance = attendance.reduce((acc, record) => {
      const date = new Date(record.date).toDateString();
      if (!acc[date]) {
        acc[date] = { present: 0, absent: 0, late: 0, total: 0 };
      }
      acc[date][record.status as keyof typeof acc[typeof date]]++;
      acc[date].total++;
      return acc;
    }, {} as Record<string, { present: number; absent: number; late: number; total: number }>);

    res.json({
      students: attendanceReport,
      dailySummary: Object.entries(dailyAttendance).map(([date, data]) => ({
        date,
        ...data,
        attendanceRate: ((data.present / data.total) * 100).toFixed(1)
      })),
      overallSummary: {
        totalStudents: attendanceReport.length,
        averageAttendance: attendanceReport.reduce((sum, s) => sum + parseFloat(s.attendanceRate), 0) / attendanceReport.length || 0,
        chronicAbsentees: attendanceReport.filter(s => parseFloat(s.attendanceRate) < 75).length
      }
    });
  } catch (error) {
    console.error("Error generating attendance report:", error);
    res.status(500).json({ message: "Failed to generate attendance report" });
  }
});

export default router;