import { db } from "./db";
import { users, students, teachers, subjects, classes, fees } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database...");

  // Create admin user
  const [adminUser] = await db.insert(users).values({
    username: "admin",
    password: "admin123",
    email: "admin@school.edu",
    firstName: "System",
    lastName: "Administrator",
    role: "admin",
    isActive: true,
  }).returning();

  // Create teacher user
  const [teacherUser] = await db.insert(users).values({
    username: "teacher",
    password: "teacher123",
    email: "teacher@school.edu",
    firstName: "John",
    lastName: "Smith",
    role: "teacher",
    isActive: true,
  }).returning();

  // Create student user
  const [studentUser] = await db.insert(users).values({
    username: "student",
    password: "student123",
    email: "student@school.edu",
    firstName: "Jane",
    lastName: "Doe",
    role: "student",
    isActive: true,
  }).returning();

  // Create teacher profile
  const [teacher] = await db.insert(teachers).values({
    userId: teacherUser.id,
    employeeId: "T001",
    department: "Mathematics",
    subject: "Mathematics",
    qualification: "M.Ed Mathematics",
    experience: 5,
    phone: "+1-555-0123",
  }).returning();

  // Create student profile
  const [student] = await db.insert(students).values({
    userId: studentUser.id,
    studentId: "S001",
    grade: "10",
    section: "A",
    dateOfBirth: new Date("2008-01-15"),
    guardianName: "Robert Doe",
    guardianPhone: "+1-555-0456",
    guardianEmail: "robert.doe@email.com",
    address: "123 Main Street, City, State 12345",
  }).returning();

  // Create subjects
  const [mathSubject] = await db.insert(subjects).values({
    name: "Mathematics",
    code: "MATH10",
    grade: "10",
    description: "Algebra and Geometry for Grade 10",
    credits: 4,
    isActive: true,
  }).returning();

  const [scienceSubject] = await db.insert(subjects).values({
    name: "Science",
    code: "SCI10",
    grade: "10",
    description: "Physics, Chemistry and Biology for Grade 10",
    credits: 4,
    isActive: true,
  }).returning();

  // Create classes
  await db.insert(classes).values({
    grade: "10",
    section: "A",
    subjectId: mathSubject.id,
    teacherId: teacher.id,
    room: "Room 101",
    schedule: "Mon, Wed, Fri 9:00-10:00 AM",
    isActive: true,
  });

  await db.insert(classes).values({
    grade: "10",
    section: "A",
    subjectId: scienceSubject.id,
    teacherId: teacher.id,
    room: "Room 102",
    schedule: "Tue, Thu 10:00-11:00 AM",
    isActive: true,
  });

  // Create sample fees
  await db.insert(fees).values({
    studentId: student.id,
    amount: "500.00",
    feeType: "Tuition",
    dueDate: new Date("2024-02-01"),
    status: "pending",
    description: "Monthly tuition fee for January 2024",
  });

  await db.insert(fees).values({
    studentId: student.id,
    amount: "100.00",
    feeType: "Lab Fee",
    dueDate: new Date("2024-02-15"),
    status: "pending",
    description: "Science laboratory fee",
  });

  console.log("Database seeded successfully!");
}

seedDatabase().catch(console.error);