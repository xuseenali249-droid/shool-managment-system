import { Client } from "@notionhq/client";
import { notion, NOTION_PAGE_ID, createDatabaseIfNotExists, findDatabaseByTitle } from "./notion";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

// Setup databases for the School Management System
async function setupNotionDatabases() {
    console.log("Setting up Notion databases...");

    // Create Students Database
    await createDatabaseIfNotExists("Students", {
        Name: {
            title: {}
        },
        StudentID: {
            rich_text: {}
        },
        Grade: {
            select: {
                options: [
                    { name: "9", color: "blue" },
                    { name: "10", color: "green" },
                    { name: "11", color: "orange" },
                    { name: "12", color: "purple" }
                ]
            }
        },
        Section: {
            select: {
                options: [
                    { name: "A", color: "blue" },
                    { name: "B", color: "green" },
                    { name: "C", color: "orange" },
                    { name: "D", color: "purple" }
                ]
            }
        },
        Email: {
            email: {}
        },
        Phone: {
            phone_number: {}
        },
        GuardianName: {
            rich_text: {}
        },
        GuardianPhone: {
            phone_number: {}
        },
        EnrollmentDate: {
            date: {}
        },
        Status: {
            select: {
                options: [
                    { name: "Active", color: "green" },
                    { name: "Inactive", color: "red" },
                    { name: "Graduated", color: "blue" },
                    { name: "Transferred", color: "orange" }
                ]
            }
        }
    });

    // Create Teachers Database
    await createDatabaseIfNotExists("Teachers", {
        Name: {
            title: {}
        },
        EmployeeID: {
            rich_text: {}
        },
        Department: {
            select: {
                options: [
                    { name: "Mathematics", color: "blue" },
                    { name: "Science", color: "green" },
                    { name: "English", color: "orange" },
                    { name: "History", color: "purple" },
                    { name: "Physical Education", color: "red" },
                    { name: "Arts", color: "pink" }
                ]
            }
        },
        Subject: {
            multi_select: {
                options: [
                    { name: "Mathematics", color: "blue" },
                    { name: "Physics", color: "green" },
                    { name: "Chemistry", color: "orange" },
                    { name: "Biology", color: "purple" },
                    { name: "English", color: "red" },
                    { name: "History", color: "pink" },
                    { name: "Geography", color: "brown" }
                ]
            }
        },
        Email: {
            email: {}
        },
        Phone: {
            phone_number: {}
        },
        Qualification: {
            rich_text: {}
        },
        Experience: {
            number: {}
        },
        HireDate: {
            date: {}
        },
        Status: {
            select: {
                options: [
                    { name: "Active", color: "green" },
                    { name: "Inactive", color: "red" },
                    { name: "On Leave", color: "orange" }
                ]
            }
        }
    });

    // Create Attendance Database
    await createDatabaseIfNotExists("Attendance", {
        Date: {
            date: {}
        },
        StudentName: {
            title: {}
        },
        StudentID: {
            rich_text: {}
        },
        Grade: {
            select: {
                options: [
                    { name: "9", color: "blue" },
                    { name: "10", color: "green" },
                    { name: "11", color: "orange" },
                    { name: "12", color: "purple" }
                ]
            }
        },
        Section: {
            select: {
                options: [
                    { name: "A", color: "blue" },
                    { name: "B", color: "green" },
                    { name: "C", color: "orange" },
                    { name: "D", color: "purple" }
                ]
            }
        },
        Status: {
            select: {
                options: [
                    { name: "Present", color: "green" },
                    { name: "Absent", color: "red" },
                    { name: "Late", color: "orange" },
                    { name: "Excused", color: "blue" }
                ]
            }
        },
        Subject: {
            select: {
                options: [
                    { name: "Mathematics", color: "blue" },
                    { name: "Science", color: "green" },
                    { name: "English", color: "orange" },
                    { name: "History", color: "purple" }
                ]
            }
        },
        Remarks: {
            rich_text: {}
        },
        MarkedBy: {
            rich_text: {}
        }
    });

    // Create Fees Database
    await createDatabaseIfNotExists("Fees", {
        StudentName: {
            title: {}
        },
        StudentID: {
            rich_text: {}
        },
        FeeType: {
            select: {
                options: [
                    { name: "Tuition", color: "blue" },
                    { name: "Lab Fee", color: "green" },
                    { name: "Library Fee", color: "orange" },
                    { name: "Sports Fee", color: "purple" },
                    { name: "Exam Fee", color: "red" }
                ]
            }
        },
        Amount: {
            number: {
                format: "dollar"
            }
        },
        DueDate: {
            date: {}
        },
        Status: {
            select: {
                options: [
                    { name: "Pending", color: "orange" },
                    { name: "Paid", color: "green" },
                    { name: "Overdue", color: "red" },
                    { name: "Partial", color: "yellow" }
                ]
            }
        },
        PaymentDate: {
            date: {}
        },
        PaymentMethod: {
            select: {
                options: [
                    { name: "Cash", color: "green" },
                    { name: "Check", color: "blue" },
                    { name: "Bank Transfer", color: "purple" },
                    { name: "Online", color: "orange" }
                ]
            }
        },
        Description: {
            rich_text: {}
        }
    });

    console.log("Notion databases setup complete!");
}

async function createSampleData() {
    try {
        console.log("Adding sample data to Notion...");

        // Find the databases
        const studentsDb = await findDatabaseByTitle("Students");
        const teachersDb = await findDatabaseByTitle("Teachers");
        const attendanceDb = await findDatabaseByTitle("Attendance");
        const feesDb = await findDatabaseByTitle("Fees");

        if (!studentsDb || !teachersDb || !attendanceDb || !feesDb) {
            throw new Error("Could not find the required databases.");
        }

        // Add sample students
        const students = [
            {
                name: "Jane Doe",
                studentId: "S001",
                grade: "10",
                section: "A",
                email: "jane.doe@email.com",
                guardianName: "Robert Doe",
                guardianPhone: "+1-555-0456"
            },
            {
                name: "John Smith",
                studentId: "S002",
                grade: "10",
                section: "A",
                email: "john.smith@email.com",
                guardianName: "Mary Smith",
                guardianPhone: "+1-555-0789"
            }
        ];

        for (let student of students) {
            await notion.pages.create({
                parent: {
                    database_id: studentsDb.id
                },
                properties: {
                    Name: {
                        title: [
                            {
                                text: {
                                    content: student.name
                                }
                            }
                        ]
                    },
                    StudentID: {
                        rich_text: [
                            {
                                text: {
                                    content: student.studentId
                                }
                            }
                        ]
                    },
                    Grade: {
                        select: {
                            name: student.grade
                        }
                    },
                    Section: {
                        select: {
                            name: student.section
                        }
                    },
                    Email: {
                        email: student.email
                    },
                    GuardianName: {
                        rich_text: [
                            {
                                text: {
                                    content: student.guardianName
                                }
                            }
                        ]
                    },
                    GuardianPhone: {
                        phone_number: student.guardianPhone
                    },
                    EnrollmentDate: {
                        date: {
                            start: new Date().toISOString().split('T')[0]
                        }
                    },
                    Status: {
                        select: {
                            name: "Active"
                        }
                    }
                }
            });
        }

        // Add sample teachers
        const teachers = [
            {
                name: "John Smith",
                employeeId: "T001",
                department: "Mathematics",
                subjects: ["Mathematics"],
                email: "john.smith@school.edu",
                phone: "+1-555-0123",
                qualification: "M.Ed Mathematics",
                experience: 5
            },
            {
                name: "Sarah Johnson",
                employeeId: "T002",
                department: "Science",
                subjects: ["Physics", "Chemistry"],
                email: "sarah.johnson@school.edu",
                phone: "+1-555-0234",
                qualification: "M.Sc Physics",
                experience: 8
            }
        ];

        for (let teacher of teachers) {
            await notion.pages.create({
                parent: {
                    database_id: teachersDb.id
                },
                properties: {
                    Name: {
                        title: [
                            {
                                text: {
                                    content: teacher.name
                                }
                            }
                        ]
                    },
                    EmployeeID: {
                        rich_text: [
                            {
                                text: {
                                    content: teacher.employeeId
                                }
                            }
                        ]
                    },
                    Department: {
                        select: {
                            name: teacher.department
                        }
                    },
                    Subject: {
                        multi_select: teacher.subjects.map(subject => ({ name: subject }))
                    },
                    Email: {
                        email: teacher.email
                    },
                    Phone: {
                        phone_number: teacher.phone
                    },
                    Qualification: {
                        rich_text: [
                            {
                                text: {
                                    content: teacher.qualification
                                }
                            }
                        ]
                    },
                    Experience: {
                        number: teacher.experience
                    },
                    HireDate: {
                        date: {
                            start: new Date().toISOString().split('T')[0]
                        }
                    },
                    Status: {
                        select: {
                            name: "Active"
                        }
                    }
                }
            });
        }

        console.log("Sample data creation complete.");
    } catch (error) {
        console.error("Error creating sample data:", error);
    }
}

// Run the setup
setupNotionDatabases().then(() => {
    return createSampleData();
}).then(() => {
    console.log("Notion integration setup complete!");
    process.exit(0);
}).catch(error => {
    console.error("Setup failed:", error);
    process.exit(1);
});