import {
  users, students, teachers, subjects, classes, attendance, fees, payments,
  type User, type InsertUser, type Student, type InsertStudent,
  type Teacher, type InsertTeacher, type Subject, type InsertSubject,
  type Class, type InsertClass, type Attendance, type InsertAttendance,
  type Fee, type InsertFee, type Payment, type InsertPayment
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Students
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByUserId(userId: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  getAllStudents(): Promise<Student[]>;
  getStudentsByGrade(grade: string): Promise<Student[]>;
  
  // Teachers
  getTeacher(id: number): Promise<Teacher | undefined>;
  getTeacherByUserId(userId: number): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined>;
  getAllTeachers(): Promise<Teacher[]>;
  
  // Subjects
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject | undefined>;
  getAllSubjects(): Promise<Subject[]>;
  getSubjectsByGrade(grade: string): Promise<Subject[]>;
  
  // Classes
  getClass(id: number): Promise<Class | undefined>;
  createClass(classData: InsertClass): Promise<Class>;
  updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined>;
  getAllClasses(): Promise<Class[]>;
  getClassesByTeacher(teacherId: number): Promise<Class[]>;
  
  // Attendance
  getAttendance(id: number): Promise<Attendance | undefined>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendanceByStudent(studentId: number, date?: Date): Promise<Attendance[]>;
  getAttendanceByClass(classId: number, date?: Date): Promise<Attendance[]>;
  getAllAttendance(): Promise<Attendance[]>;
  
  // Fees
  getFee(id: number): Promise<Fee | undefined>;
  createFee(fee: InsertFee): Promise<Fee>;
  updateFee(id: number, fee: Partial<InsertFee>): Promise<Fee | undefined>;
  getFeesByStudent(studentId: number): Promise<Fee[]>;
  getAllFees(): Promise<Fee[]>;
  
  // Payments
  getPayment(id: number): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByFee(feeId: number): Promise<Payment[]>;
  getAllPayments(): Promise<Payment[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private students: Map<number, Student> = new Map();
  private teachers: Map<number, Teacher> = new Map();
  private subjects: Map<number, Subject> = new Map();
  private classes: Map<number, Class> = new Map();
  private attendance: Map<number, Attendance> = new Map();
  private fees: Map<number, Fee> = new Map();
  private payments: Map<number, Payment> = new Map();
  private currentIds = {
    users: 1,
    students: 1,
    teachers: 1,
    subjects: 1,
    classes: 1,
    attendance: 1,
    fees: 1,
    payments: 1,
  };

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create admin user
    const adminUser: User = {
      id: this.currentIds.users++,
      username: "admin",
      password: "admin123", // In real app, this would be hashed
      email: "admin@school.edu",
      role: "admin",
      firstName: "John",
      lastName: "Admin",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create sample teacher user
    const teacherUser: User = {
      id: this.currentIds.users++,
      username: "teacher1",
      password: "teacher123",
      email: "mary.smith@school.edu",
      role: "teacher",
      firstName: "Mary",
      lastName: "Smith",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(teacherUser.id, teacherUser);

    // Create sample student user
    const studentUser: User = {
      id: this.currentIds.users++,
      username: "student1",
      password: "student123",
      email: "sarah.johnson@school.edu",
      role: "student",
      firstName: "Sarah",
      lastName: "Johnson",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(studentUser.id, studentUser);

    // Create teacher profile
    const teacher: Teacher = {
      id: this.currentIds.teachers++,
      userId: teacherUser.id,
      employeeId: "EMP-001",
      department: "Mathematics",
      subject: "Mathematics",
      qualification: "M.Sc Mathematics",
      experience: 5,
      phone: "+1234567890",
      hireDate: new Date(),
    };
    this.teachers.set(teacher.id, teacher);

    // Create student profile
    const student: Student = {
      id: this.currentIds.students++,
      userId: studentUser.id,
      studentId: "STU-2024-001",
      grade: "10",
      section: "A",
      dateOfBirth: new Date("2008-05-15"),
      guardianName: "Robert Johnson",
      guardianPhone: "+1987654321",
      guardianEmail: "robert.johnson@email.com",
      address: "123 Main St, City, State",
      enrollmentDate: new Date(),
    };
    this.students.set(student.id, student);

    // Create sample subject
    const subject: Subject = {
      id: this.currentIds.subjects++,
      name: "Mathematics",
      code: "MATH-10",
      description: "Advanced Algebra",
      grade: "10",
      credits: 3,
      isActive: true,
    };
    this.subjects.set(subject.id, subject);

    // Create sample class
    const classData: Class = {
      id: this.currentIds.classes++,
      subjectId: subject.id,
      teacherId: teacher.id,
      grade: "10",
      section: "A",
      room: "101",
      schedule: JSON.stringify([
        { day: "Monday", time: "09:00" },
        { day: "Wednesday", time: "09:00" },
        { day: "Friday", time: "09:00" }
      ]),
      isActive: true,
    };
    this.classes.set(classData.id, classData);

    // Create sample fee
    const fee: Fee = {
      id: this.currentIds.fees++,
      studentId: student.id,
      amount: "1200.00",
      feeType: "tuition",
      dueDate: new Date("2024-12-31"),
      status: "pending",
      description: "Monthly tuition fee",
      createdAt: new Date(),
    };
    this.fees.set(fee.id, fee);
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const user: User = {
      ...userData,
      id: this.currentIds.users++,
      role: userData.role || "student",
      isActive: userData.isActive ?? true,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Students
  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentByUserId(userId: number): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(student => student.userId === userId);
  }

  async createStudent(studentData: InsertStudent): Promise<Student> {
    const student: Student = {
      id: this.currentIds.students++,
      userId: studentData.userId,
      studentId: studentData.studentId,
      grade: studentData.grade,
      section: studentData.section,
      dateOfBirth: studentData.dateOfBirth,
      guardianName: studentData.guardianName,
      guardianPhone: studentData.guardianPhone,
      guardianEmail: studentData.guardianEmail || null,
      address: studentData.address || null,
      enrollmentDate: new Date(),
    };
    this.students.set(student.id, student);
    return student;
  }

  async updateStudent(id: number, studentData: Partial<InsertStudent>): Promise<Student | undefined> {
    const student = this.students.get(id);
    if (!student) return undefined;
    
    const updatedStudent = { ...student, ...studentData };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async getAllStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudentsByGrade(grade: string): Promise<Student[]> {
    return Array.from(this.students.values()).filter(student => student.grade === grade);
  }

  // Teachers
  async getTeacher(id: number): Promise<Teacher | undefined> {
    return this.teachers.get(id);
  }

  async getTeacherByUserId(userId: number): Promise<Teacher | undefined> {
    return Array.from(this.teachers.values()).find(teacher => teacher.userId === userId);
  }

  async createTeacher(teacherData: InsertTeacher): Promise<Teacher> {
    const teacher: Teacher = {
      id: this.currentIds.teachers++,
      userId: teacherData.userId,
      employeeId: teacherData.employeeId,
      department: teacherData.department,
      subject: teacherData.subject,
      qualification: teacherData.qualification || null,
      experience: teacherData.experience || null,
      phone: teacherData.phone || null,
      hireDate: new Date(),
    };
    this.teachers.set(teacher.id, teacher);
    return teacher;
  }

  async updateTeacher(id: number, teacherData: Partial<InsertTeacher>): Promise<Teacher | undefined> {
    const teacher = this.teachers.get(id);
    if (!teacher) return undefined;
    
    const updatedTeacher = { ...teacher, ...teacherData };
    this.teachers.set(id, updatedTeacher);
    return updatedTeacher;
  }

  async getAllTeachers(): Promise<Teacher[]> {
    return Array.from(this.teachers.values());
  }

  // Subjects
  async getSubject(id: number): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  async createSubject(subjectData: InsertSubject): Promise<Subject> {
    const subject: Subject = {
      id: this.currentIds.subjects++,
      name: subjectData.name,
      code: subjectData.code,
      grade: subjectData.grade,
      description: subjectData.description || null,
      credits: subjectData.credits || null,
      isActive: subjectData.isActive ?? true,
    };
    this.subjects.set(subject.id, subject);
    return subject;
  }

  async updateSubject(id: number, subjectData: Partial<InsertSubject>): Promise<Subject | undefined> {
    const subject = this.subjects.get(id);
    if (!subject) return undefined;
    
    const updatedSubject = { ...subject, ...subjectData };
    this.subjects.set(id, updatedSubject);
    return updatedSubject;
  }

  async getAllSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubjectsByGrade(grade: string): Promise<Subject[]> {
    return Array.from(this.subjects.values()).filter(subject => subject.grade === grade);
  }

  // Classes
  async getClass(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }

  async createClass(classData: InsertClass): Promise<Class> {
    const newClass: Class = {
      id: this.currentIds.classes++,
      grade: classData.grade,
      section: classData.section,
      subjectId: classData.subjectId,
      teacherId: classData.teacherId,
      room: classData.room || null,
      schedule: classData.schedule || null,
      isActive: classData.isActive ?? true,
    };
    this.classes.set(newClass.id, newClass);
    return newClass;
  }

  async updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined> {
    const existingClass = this.classes.get(id);
    if (!existingClass) return undefined;
    
    const updatedClass = { ...existingClass, ...classData };
    this.classes.set(id, updatedClass);
    return updatedClass;
  }

  async getAllClasses(): Promise<Class[]> {
    return Array.from(this.classes.values());
  }

  async getClassesByTeacher(teacherId: number): Promise<Class[]> {
    return Array.from(this.classes.values()).filter(cls => cls.teacherId === teacherId);
  }

  // Attendance
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendance.get(id);
  }

  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const attendance: Attendance = {
      id: this.currentIds.attendance++,
      date: attendanceData.date,
      status: attendanceData.status,
      studentId: attendanceData.studentId,
      classId: attendanceData.classId,
      markedBy: attendanceData.markedBy,
      remarks: attendanceData.remarks || null,
      markedAt: new Date(),
    };
    this.attendance.set(attendance.id, attendance);
    return attendance;
  }

  async getAttendanceByStudent(studentId: number, date?: Date): Promise<Attendance[]> {
    let records = Array.from(this.attendance.values()).filter(record => record.studentId === studentId);
    
    if (date) {
      const targetDate = date.toDateString();
      records = records.filter(record => record.date.toDateString() === targetDate);
    }
    
    return records;
  }

  async getAttendanceByClass(classId: number, date?: Date): Promise<Attendance[]> {
    let records = Array.from(this.attendance.values()).filter(record => record.classId === classId);
    
    if (date) {
      const targetDate = date.toDateString();
      records = records.filter(record => record.date.toDateString() === targetDate);
    }
    
    return records;
  }

  async getAllAttendance(): Promise<Attendance[]> {
    return Array.from(this.attendance.values());
  }

  // Fees
  async getFee(id: number): Promise<Fee | undefined> {
    return this.fees.get(id);
  }

  async createFee(feeData: InsertFee): Promise<Fee> {
    const fee: Fee = {
      id: this.currentIds.fees++,
      studentId: feeData.studentId,
      amount: feeData.amount,
      feeType: feeData.feeType,
      dueDate: feeData.dueDate,
      status: feeData.status || "pending",
      description: feeData.description || null,
      createdAt: new Date(),
    };
    this.fees.set(fee.id, fee);
    return fee;
  }

  async updateFee(id: number, feeData: Partial<InsertFee>): Promise<Fee | undefined> {
    const fee = this.fees.get(id);
    if (!fee) return undefined;
    
    const updatedFee = { ...fee, ...feeData };
    this.fees.set(id, updatedFee);
    return updatedFee;
  }

  async getFeesByStudent(studentId: number): Promise<Fee[]> {
    return Array.from(this.fees.values()).filter(fee => fee.studentId === studentId);
  }

  async getAllFees(): Promise<Fee[]> {
    return Array.from(this.fees.values());
  }

  // Payments
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async createPayment(paymentData: InsertPayment): Promise<Payment> {
    const payment: Payment = {
      id: this.currentIds.payments++,
      amount: paymentData.amount,
      feeId: paymentData.feeId,
      paymentMethod: paymentData.paymentMethod,
      receivedBy: paymentData.receivedBy,
      transactionId: paymentData.transactionId || null,
      paidAt: new Date(),
    };
    this.payments.set(payment.id, payment);
    return payment;
  }

  async getPaymentsByFee(feeId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(payment => payment.feeId === feeId);
  }

  async getAllPayments(): Promise<Payment[]> {
    return Array.from(this.payments.values());
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        role: userData.role || "student",
        isActive: userData.isActive ?? true,
      })
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Students
  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student || undefined;
  }

  async getStudentByUserId(userId: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.userId, userId));
    return student || undefined;
  }

  async createStudent(studentData: InsertStudent): Promise<Student> {
    const [student] = await db
      .insert(students)
      .values({
        ...studentData,
        guardianEmail: studentData.guardianEmail || null,
        address: studentData.address || null,
      })
      .returning();
    return student;
  }

  async updateStudent(id: number, studentData: Partial<InsertStudent>): Promise<Student | undefined> {
    const [student] = await db
      .update(students)
      .set(studentData)
      .where(eq(students.id, id))
      .returning();
    return student || undefined;
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students);
  }

  async getStudentsByGrade(grade: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.grade, grade));
  }

  // Teachers
  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher || undefined;
  }

  async getTeacherByUserId(userId: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.userId, userId));
    return teacher || undefined;
  }

  async createTeacher(teacherData: InsertTeacher): Promise<Teacher> {
    const [teacher] = await db
      .insert(teachers)
      .values({
        ...teacherData,
        qualification: teacherData.qualification || null,
        experience: teacherData.experience || null,
        phone: teacherData.phone || null,
      })
      .returning();
    return teacher;
  }

  async updateTeacher(id: number, teacherData: Partial<InsertTeacher>): Promise<Teacher | undefined> {
    const [teacher] = await db
      .update(teachers)
      .set(teacherData)
      .where(eq(teachers.id, id))
      .returning();
    return teacher || undefined;
  }

  async getAllTeachers(): Promise<Teacher[]> {
    return await db.select().from(teachers);
  }

  // Subjects
  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject || undefined;
  }

  async createSubject(subjectData: InsertSubject): Promise<Subject> {
    const [subject] = await db
      .insert(subjects)
      .values({
        ...subjectData,
        description: subjectData.description || null,
        credits: subjectData.credits || null,
        isActive: subjectData.isActive ?? true,
      })
      .returning();
    return subject;
  }

  async updateSubject(id: number, subjectData: Partial<InsertSubject>): Promise<Subject | undefined> {
    const [subject] = await db
      .update(subjects)
      .set(subjectData)
      .where(eq(subjects.id, id))
      .returning();
    return subject || undefined;
  }

  async getAllSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubjectsByGrade(grade: string): Promise<Subject[]> {
    return await db.select().from(subjects).where(eq(subjects.grade, grade));
  }

  // Classes
  async getClass(id: number): Promise<Class | undefined> {
    const [classItem] = await db.select().from(classes).where(eq(classes.id, id));
    return classItem || undefined;
  }

  async createClass(classData: InsertClass): Promise<Class> {
    const [classItem] = await db
      .insert(classes)
      .values({
        ...classData,
        room: classData.room || null,
        schedule: classData.schedule || null,
        isActive: classData.isActive ?? true,
      })
      .returning();
    return classItem;
  }

  async updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined> {
    const [classItem] = await db
      .update(classes)
      .set(classData)
      .where(eq(classes.id, id))
      .returning();
    return classItem || undefined;
  }

  async getAllClasses(): Promise<Class[]> {
    return await db.select().from(classes);
  }

  async getClassesByTeacher(teacherId: number): Promise<Class[]> {
    return await db.select().from(classes).where(eq(classes.teacherId, teacherId));
  }

  // Attendance
  async getAttendance(id: number): Promise<Attendance | undefined> {
    const [attendanceRecord] = await db.select().from(attendance).where(eq(attendance.id, id));
    return attendanceRecord || undefined;
  }

  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [attendanceRecord] = await db
      .insert(attendance)
      .values({
        ...attendanceData,
        remarks: attendanceData.remarks || null,
      })
      .returning();
    return attendanceRecord;
  }

  async getAttendanceByStudent(studentId: number, date?: Date): Promise<Attendance[]> {
    let query = db.select().from(attendance).where(eq(attendance.studentId, studentId));
    
    if (date) {
      query = query.where(eq(attendance.date, date));
    }
    
    return await query;
  }

  async getAttendanceByClass(classId: number, date?: Date): Promise<Attendance[]> {
    let query = db.select().from(attendance).where(eq(attendance.classId, classId));
    
    if (date) {
      query = query.where(eq(attendance.date, date));
    }
    
    return await query;
  }

  async getAllAttendance(): Promise<Attendance[]> {
    return await db.select().from(attendance);
  }

  // Fees
  async getFee(id: number): Promise<Fee | undefined> {
    const [fee] = await db.select().from(fees).where(eq(fees.id, id));
    return fee || undefined;
  }

  async createFee(feeData: InsertFee): Promise<Fee> {
    const [fee] = await db
      .insert(fees)
      .values({
        ...feeData,
        status: feeData.status || "pending",
        description: feeData.description || null,
      })
      .returning();
    return fee;
  }

  async updateFee(id: number, feeData: Partial<InsertFee>): Promise<Fee | undefined> {
    const [fee] = await db
      .update(fees)
      .set(feeData)
      .where(eq(fees.id, id))
      .returning();
    return fee || undefined;
  }

  async getFeesByStudent(studentId: number): Promise<Fee[]> {
    return await db.select().from(fees).where(eq(fees.studentId, studentId));
  }

  async getAllFees(): Promise<Fee[]> {
    return await db.select().from(fees);
  }

  // Payments
  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment || undefined;
  }

  async createPayment(paymentData: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values({
        ...paymentData,
        transactionId: paymentData.transactionId || null,
      })
      .returning();
    return payment;
  }

  async getPaymentsByFee(feeId: number): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.feeId, feeId));
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments);
  }
}

export const storage = new DatabaseStorage();
